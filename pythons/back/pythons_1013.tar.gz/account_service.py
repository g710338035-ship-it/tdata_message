import os
import asyncio
import subprocess
import hashlib
import stat
import pwd
import grp
import json
from datetime import datetime
from telethon import TelegramClient
from telethon.sessions import MemorySession
from telethon.tl.functions.help import GetConfigRequest
from telethon.errors import AuthKeyError, RPCError
from telethon.tl.functions.account import (
    UpdateProfileRequest
)
import phonenumbers
from phonenumbers import geocoder

def set_session_permissions(session_path):
    """将session文件和目录权限设置为www用户和755权限"""
    try:
        # 1. 确认文件路径
        if not os.path.exists(session_path):
            session_path_with_ext = f"{session_path}.session"
            if os.path.exists(session_path_with_ext):
                session_path = session_path_with_ext
            else:
                return False, "会话文件不存在"
        
        # 2. 获取www用户和用户组信息
        try:
            www_user = pwd.getpwnam("www")
            www_uid = www_user.pw_uid
            www_gid = www_user.pw_gid
            
            www_group = grp.getgrgid(www_gid)
            www_group_name = www_group.gr_name
        except KeyError:
            return False, "未找到www或其他web用户（nginx/apache/www-data）"
        
        # 3. 检查并移除特殊属性
        try:
            if subprocess.run(
                f"lsattr {session_path} | grep -q 'i'", 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE
            ).returncode == 0:
                
                subprocess.run(
                    f"chattr -i {session_path}",
                    shell=True,
                    check=True
                )
        except Exception as e:
            return False, f"移除文件特殊属性失败: {str(e)}"
        
        # 4. 强制更改所有者为www用户
        try:
            os.chown(session_path, www_uid, www_gid)
        except PermissionError:
            try:
                subprocess.run(
                    f"sudo chown {www_uid}:{www_gid} {session_path}",
                    shell=True,
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            except Exception as e:
                return False, f"更改文件所有者为www失败: {str(e)}"
        
        # 5. 强制设置文件权限为755
        try:
            os.chmod(session_path, 
                     stat.S_IRWXU |  # 用户：读、写、执行
                     stat.S_IRGRP | stat.S_IXGRP |  # 组：读、执行
                     stat.S_IROTH | stat.S_IXOTH)  # 其他：读、执行
        except PermissionError:
            try:
                subprocess.run(
                    f"sudo chmod 755 {session_path}",
                    shell=True,
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            except Exception as e:
                return False, f"设置文件权限为755失败: {str(e)}"
        
        # 6. 处理目录权限
        session_dir = os.path.dirname(session_path)
        if os.path.exists(session_dir):
            # 移除目录特殊属性
            try:
                if subprocess.run(
                    f"lsattr {session_dir} | grep -q 'i'", 
                    shell=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE
                ).returncode == 0:
                    
                    subprocess.run(
                        f"chattr -i {session_dir}",
                        shell=True,
                        check=True
                    )
            except Exception as e:
                return False, f"移除目录特殊属性失败: {str(e)}"
            
            # 更改目录所有者为www
            try:
                os.chown(session_dir, www_uid, www_gid)
            except PermissionError:
                try:
                    subprocess.run(
                        f"sudo chown {www_uid}:{www_gid} {session_dir}",
                        shell=True,
                        check=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                except Exception as e:
                    return False, f"更改目录所有者为www失败: {str(e)}"
            
            # 设置目录权限为755
            try:
                os.chmod(session_dir, 
                         stat.S_IRWXU |  # 用户：读、写、执行
                         stat.S_IRGRP | stat.S_IXGRP |  # 组：读、执行
                         stat.S_IROTH | stat.S_IXOTH)  # 其他：读、执行
            except PermissionError:
                try:
                    subprocess.run(
                        f"sudo chmod 755 {session_dir}",
                        shell=True,
                        check=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                except Exception as e:
                    return False, f"设置目录权限为755失败: {str(e)}"
        
        # 7. 验证最终权限
        file_stat = os.stat(session_path)
        file_perms = oct(stat.S_IMODE(file_stat.st_mode))
        file_owner = pwd.getpwuid(file_stat.st_uid).pw_name
        file_group = grp.getgrgid(file_stat.st_gid).gr_name
        
        dir_perms = "N/A"
        dir_owner = "N/A"
        dir_group = "N/A"
        if os.path.exists(session_dir):
            dir_stat = os.stat(session_dir)
            dir_perms = oct(stat.S_IMODE(dir_stat.st_mode))
            dir_owner = pwd.getpwuid(dir_stat.st_uid).pw_name
            dir_group = grp.getgrgid(dir_stat.st_gid).gr_name
        
        return True, (f"权限设置成功 - "
                     f"文件: 权限={file_perms}, 所有者={file_owner}:{file_group}; "
                     f"目录: 权限={dir_perms}, 所有者={dir_owner}:{dir_group}")
                     
    except Exception as e:
        return False, f"权限设置过程发生错误: {str(e)}"

def run_tdesktop_decrypter(tdata_path, passcode=None):
    """调用tdesktop-decrypter解密tdata，提取user_id/main_dc_id/auth_key/phone"""
    try:
        python_exec = "/www/server/pyporject_evn/versions/3.11.13/bin/python3"
        cmd = [python_exec, '-m', 'tdesktop_decrypter', '--json', tdata_path]
        if passcode:
            cmd.insert(2, '--passcode')
            cmd.insert(3, passcode)
        
        result = subprocess.run(
            cmd, 
            capture_output=True,
            text=True,
            check=True,
            timeout=30
        )
        
        decrypted_data = json.loads(result.stdout)
        if not decrypted_data.get('accounts') or len(decrypted_data['accounts']) == 0:
            return {'error': "tdata中未找到账号数据"}
        
        account = decrypted_data['accounts'][0]
        user_id = account.get('user_id')
        main_dc_id = account.get('main_dc_id')
        dc_auth_keys = account.get('dc_auth_keys', {})
        auth_key_hex = dc_auth_keys.get(str(main_dc_id))
        
        phone = account.get('phone')
        if not phone and 'config' in account and 'phone' in account['config']:
            phone = account['config']['phone']
        
        if not all([user_id, main_dc_id, auth_key_hex]):
            missing = []
            if not user_id: missing.append('user_id')
            if not main_dc_id: missing.append('main_dc_id')
            if not auth_key_hex: missing.append('auth_key')
            return {'error': f"解密结果缺少关键信息：{', '.join(missing)}"}
        
        return {
            'success': True,
            'user_id': user_id,
            'main_dc_id': main_dc_id,
            'auth_key_hex': auth_key_hex,
            'phone': phone,
            'raw_data': decrypted_data
        }
    
    except subprocess.TimeoutExpired:
        return {'error': "解密命令执行超时"}
    except subprocess.CalledProcessError as e:
        return {'error': f"解密命令执行失败：{e.stderr.strip()}"}
    except json.JSONDecodeError:
        return {'error': f"解密结果解析失败：{result.stdout[:200]}..."}
    except Exception as e:
        return {'error': f"tdata解密异常：{str(e)}"}

async def get_latest_dc_config(client):
    """通过Telethon获取实时DC配置"""
    try:
        config = await asyncio.wait_for(client(GetConfigRequest()), timeout=10)
        dc_options = config.dc_options
        
        dc_config_map = {}
        for option in dc_options:
            dc_config_map[option.id] = {
                'ip': option.ip_address,
                'port': option.port,
                'hostname': getattr(option, 'hostname', '')
            }
        
        return {'success': True, 'dc_map': dc_config_map}
    
    except asyncio.TimeoutError:
        return {'error': "获取DC配置超时"}
    except Exception as e:
        return {'error': f"获取DC配置异常：{str(e)}"}

async def build_telethon_session(tdata_path, auth_key_hex, main_dc_id, user_id, api_id, api_hash, phone=None,proxy=None, session_type="file", session_name="telegram_session", prefer_ipv6=False):
    """构建并验证Telethon会话（支持文件/字符串会话），并提取账号信息"""
    try:
        client = None  # 初始化client变量
        session_file = None  # 初始化会话文件路径变量
        
        # 构建会话部分
        if session_type == "file":
            session_file = os.path.join(tdata_path, f"temp_{user_id}.session")
            client = TelegramClient(session_file, api_id, api_hash, proxy=proxy)
            session = client.session
        else:
            session = MemorySession()
        
        class AuthKeyWrapper:
            def __init__(self, key_bytes):
                self.key = key_bytes
                sha1_hash = hashlib.sha1(key_bytes).digest()
                self.key_id = int.from_bytes(sha1_hash[-8:], byteorder='little', signed=False)
        
        auth_key_bytes = bytes.fromhex(auth_key_hex)
        session.auth_key = AuthKeyWrapper(auth_key_bytes)
        
        dc_full_map = None
        dc_selected_map = {}
        temp_client = None
        
        try:
            temp_session = MemorySession()
            temp_client = TelegramClient(temp_session, api_id, api_hash, proxy=proxy)
            await temp_client.connect()
            dc_config_result = await get_latest_dc_config(temp_client)
            
            if dc_config_result.get('success'):
                dc_full_map = dc_config_result['dc_map']
                ipv4_addresses = {}
                ipv6_addresses = {}
                
                for dc_id, config in dc_full_map.items():
                    if ':' not in config['ip']:
                        ipv4_addresses[dc_id] = config['ip']
                    else:
                        ipv6_addresses[dc_id] = config['ip']
                
                if prefer_ipv6 and ipv6_addresses:
                    dc_selected_map = ipv6_addresses
                elif ipv4_addresses:
                    dc_selected_map = ipv4_addresses
                else:
                    dc_selected_map = {k: v['ip'] for k, v in dc_full_map.items()}
        except Exception as e:
            print(f"[警告] 获取DC配置异常：{str(e)}")
        finally:
            if temp_client and temp_client.is_connected():
                await temp_client.disconnect()
        
        dc_id = int(main_dc_id)
        if not dc_selected_map or dc_id not in dc_selected_map:
            default_dc_map = {
                1: '149.154.175.50',
                2: '149.154.167.51',
                3: '149.154.175.100',
                4: '149.154.167.91',
                5: '149.154.171.5'
            }
            dc_selected_map = default_dc_map
        
        selected_ip = dc_selected_map.get(dc_id)
        if selected_ip:
            is_ipv6 = ':' in selected_ip
            session.set_dc(dc_id, selected_ip, 443)
        else:
            session.set_dc(dc_id, "", 443)
        
        # 验证会话并提取信息部分
        try:
            # 初始化客户端
            client = TelegramClient(
                session,
                api_id=api_id,
                api_hash=api_hash,
                request_retries=3,
                timeout=10,
                sequential_updates=True,
                proxy=proxy
            )
            
            # 连接验证
            if not client.is_connected():
                await asyncio.wait_for(client.connect(), timeout=15)
            
            # 验证授权状态
            is_authorized = await client.is_user_authorized()
            if not is_authorized:
                return {
                    'success': False,
                    'error': '会话未授权',
                    'account_status': '未授权',
                    'account_status_desc': '账号未授权或会话已失效',
                    #'session': session,
                    'session_file': session_file
                }
            
            # 提取用户信息
            user = await client.get_me()
            if not user:
                return {
                    'success': False,
                    'error': '无法获取用户信息',
                    'account_status': '异常',
                    'account_status_desc': '无法获取用户信息，可能是网络问题或会话无效',
                    #'session': session,
                    'session_file': session_file
                }
                                
            # 解析状态信息
            def parse_status(status):
                status_data = {"type": status.__class__.__name__, "is_online": False}
                def datetime_to_timestamp(dt):
                    return int(dt.timestamp()) if dt else None

                if hasattr(status, 'expires'):
                    status_data["is_online"] = True
                    status_data["description"] = "在线"
                    status_data["expires"] = datetime_to_timestamp(status.expires)
                elif hasattr(status, 'was_online'):
                    status_data["was_online"] = datetime_to_timestamp(status.was_online)
                elif status.__class__.__name__ == "UserStatusRecently":
                    status_data["description"] = "最近在线"
                elif status.__class__.__name__ == "UserStatusLastWeek":
                    status_data["description"] = "上周在线"
                elif status.__class__.__name__ == "UserStatusLastMonth":
                    status_data["description"] = "上月在线"
                elif status.__class__.__name__ == "UserStatusOffline":
                    status_data["is_online"] = False
                    status_data["description"] = "离线"
                return status_data
            
            status_info = parse_status(user.status)
            
            # 解析国家信息
            country = "未知"
            if user.phone:
                try:
                    phone = user.phone if user.phone.startswith('+') else '+' + user.phone
                    phone_number = phonenumbers.parse(phone, None)
                    country = geocoder.country_name_for_number(phone_number, "zh")
                except:
                    pass
            
            # 检查账号状态
            account_status = '正常'
            account_status_desc = '账号状态正常'
            if hasattr(user, 'deleted') and user.deleted:
                account_status = '注销'
                account_status_desc = '账号已被用户主动注销'
            elif hasattr(user, 'restricted') and user.restricted:
                account_status = '冻结'
                account_status_desc = '账号被冻结'
            else:
                try:
                    await client(UpdateProfileRequest())  # 测试账号是否可用
                except RPCError as rpc_err:
                    if "FROZEN_METHOD_INVALID" in str(rpc_err):
                        account_status = '冻结'
                        account_status_desc = '账号被冻结' 
            
            # 整理结果
            result = {
                'success': True,
                'user_id': user.id,
                'username': user.username,
                'nickname': (user.first_name or "") + (" " + user.last_name if user.last_name else ""),
                'phone': user.phone,
                'country': country,
                'status_info': status_info,
                'is_authorized': True,
                'account_status': account_status,
                'account_status_desc': account_status_desc,
                #'session': session,
                'session_file': session_file
            }
            
            return result
            
       
        except AuthKeyError:
            return {
                'success': False, 
                'error': '授权密钥无效，会话可能已过期或损坏', 
                'account_status': '异常', 
                'account_status_desc': '授权密钥无效', 
                #'session': session,
                'session_file': session_file,
                #'client': None
            }
        except asyncio.TimeoutError:
            return {
                'success': False, 
                'error': '连接超时', 
                'account_status': '异常', 
                'account_status_desc': '连接超时', 
                #'session': session,
                'session_file': session_file,
                'client': None
            }
        except Exception as e:
            error_str = str(e)
            account_status = '异常'
            account_status_desc = f'验证过程异常: {error_str}'
            if 'USER_DEACTIVATED' in error_str:
                account_status = '注销'
                account_status_desc = f'账号已被注销: {error_str}'
            elif 'USER_BANNED' in error_str:
                account_status = '封号'
                account_status_desc = f'账号已被封禁: {error_str}'
            elif any(code in error_str for code in ['USER_DEACTIVATED_BAN', 'USER_DELETED', 'ACCOUNT_DELETED']):
                account_status = '注销'
                account_status_desc = f'账号已被注销: {error_str}'
            return {
                'success': False, 
                'error': f'验证与提取信息失败：{error_str}', 
                'account_status': account_status, 
                'account_status_desc': account_status_desc,
                #'session': session,
                'session_file': session_file,
                #'client': None
            }
        finally:
            # 确保断开连接
            if 'client' in locals() and client and client.is_connected():
                try:
                    await client.disconnect()
                except:
                    pass
    
    except Exception as e:
        return {
            'success': False,
            'error': f'会话构建异常：{str(e)}',
            'session': None,
            'session_file': None
        }

async def verify_and_extract_info(session, api_id, api_hash,proxy):
    """使用TelegramClient验证会话并提取账号信息"""
    try:
        # 初始化客户端
        client = TelegramClient(
            session,
            api_id=api_id,
            api_hash=api_hash,
            request_retries=3,
            timeout=10,
            sequential_updates=True,
            proxy=proxy
        )
        
        # 连接验证
        if not client.is_connected():
            await asyncio.wait_for(client.connect(), timeout=15)
        
        # 验证授权状态
        is_authorized = await client.is_user_authorized()
        if not is_authorized:
            return {
                'success': False,
                'error': '会话未授权',
                'account_status': '未授权',
                'account_status_desc': '账号未授权或会话已失效',
                'client': client
            }
        
        # 提取用户信息
        user = await client.get_me()
        if not user:
            return {
                'success': False,
                'error': '无法获取用户信息',
                'account_status': '异常',
                'account_status_desc': '无法获取用户信息，可能是网络问题或会话无效',
                'client': client
            }
                            
        # 解析状态信息
        def parse_status(status):
            status_data = {"type": status.__class__.__name__, "is_online": False}
            def datetime_to_timestamp(dt):
                return int(dt.timestamp()) if dt else None

            if hasattr(status, 'expires'):
                status_data["is_online"] = True
                status_data["description"] = "在线"
                status_data["expires"] = datetime_to_timestamp(status.expires)
            elif hasattr(status, 'was_online'):
                status_data["was_online"] = datetime_to_timestamp(status.was_online)
            elif status.__class__.__name__ == "UserStatusRecently":
                status_data["description"] = "最近在线"
            elif status.__class__.__name__ == "UserStatusLastWeek":
                status_data["description"] = "上周在线"
            elif status.__class__.__name__ == "UserStatusLastMonth":
                status_data["description"] = "上月在线"
            elif status.__class__.__name__ == "UserStatusOffline":
                status_data["is_online"] = False
                status_data["description"] = "离线"
            return status_data
        
        status_info = parse_status(user.status)
        
        # 解析国家信息
        country = "未知"
        if user.phone:
            try:
                phone = user.phone if user.phone.startswith('+') else '+' + user.phone
                phone_number = phonenumbers.parse(phone, None)
                country = geocoder.country_name_for_number(phone_number, "zh")
            except:
                pass
        
        # 检查账号状态
        account_status = '正常'
        account_status_desc = '账号状态正常'
        if hasattr(user, 'deleted') and user.deleted:
            account_status = '注销'
            account_status_desc = '账号已被用户主动注销'
        elif hasattr(user, 'restricted') and user.restricted:
            account_status = '冻结'
            account_status_desc = '账号被冻结'
        else:
            try:
                await client(UpdateProfileRequest())  # 测试账号是否可用
            except RPCError as rpc_err:
                if "FROZEN_METHOD_INVALID" in str(rpc_err):
                    account_status = '冻结'
                    account_status_desc = '账号被冻结' 
        
        # 整理结果
        result = {
            'success': True,
            'user_id': user.id,
            'username': user.username,
            'nickname': (user.first_name or "") + (" " + user.last_name if user.last_name else ""),
            'phone': user.phone,
            'country': country,
            'status_info': status_info,
            'is_authorized': True,
            'account_status': account_status,
            'account_status_desc': account_status_desc,
            #'client': client
        }
        
        return result
        
   
    except AuthKeyError:
        return {'success': False, 'error': '授权密钥无效，会话可能已过期或损坏', 'account_status': '异常', 'account_status_desc': '授权密钥无效', 'client': None}
    except asyncio.TimeoutError:
        return {'success': False, 'error': '连接超时', 'account_status': '异常', 'account_status_desc': '连接超时', 'client': None}
    except Exception as e:
        error_str = str(e)
        account_status = '异常'
        account_status_desc = f'验证过程异常: {error_str}'
        if 'USER_DEACTIVATED' in error_str:
            account_status = '注销'
            account_status_desc = f'账号已被注销: {error_str}'
        elif 'USER_BANNED' in error_str:
            account_status = '封号'
            account_status_desc = f'账号已被封禁: {error_str}'
        elif any(code in error_str for code in ['USER_DEACTIVATED_BAN', 'USER_DELETED', 'ACCOUNT_DELETED']):
            account_status = '注销'
            account_status_desc = f'账号已被注销: {error_str}'
        return {'success': False, 'error': f'验证与提取信息失败：{error_str}', 'account_status': account_status, 'account_status_desc': account_status_desc, 'client': None}
    finally:
        # 确保断开连接
        if 'client' in locals() and client and client.is_connected():
            try:
                await client.disconnect()
            except:
                pass

def timestamp_to_datetime(timestamp, format_str="%Y-%m-%d %H:%M:%S"):
    """时间戳转换为格式化日期时间"""
    if not timestamp:
        return "未知时间"
    try:
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime(format_str)
    except Exception:
        return f"无效时间戳: {timestamp}"