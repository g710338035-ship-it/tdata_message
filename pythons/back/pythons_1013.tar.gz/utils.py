from datetime import datetime

def datetime_to_timestamp(dt):
    """将datetime对象转换为Unix时间戳"""
    if isinstance(dt, datetime):
        return int(dt.timestamp())
    return None

def parse_status(status):
    """解析Telegram用户状态对象"""
    status_data = {
        "type": status.__class__.__name__,
        "is_online": False
    }
    if hasattr(status, 'expires'):
        status_data["is_online"] = True
        status_data["expires"] = datetime_to_timestamp(status.expires)
    elif hasattr(status, 'was_online'):
        status_data["was_online"] = datetime_to_timestamp(status.was_online)
    return status_data
    