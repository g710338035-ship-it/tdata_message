import os
import asyncio
import time
import hashlib
from opentele.td import TDesktop
from opentele.api import UseCurrentSession
from telethon.tl.functions.account import (
    UpdateStatusRequest, 
    UpdateProfileRequest,
    UpdateUsernameRequest,
    UpdatePasswordSettingsRequest,
    GetAuthorizationsRequest,  # 获取其他设备用
    ResetAuthorizationRequest  # 退出其他设备用
)
from telethon import TelegramClient
from telethon.tl.functions.contacts import (
    GetContactsRequest, BlockRequest,
    DeleteContactsRequest  # 删除好友用
)

from telethon.tl.functions.channels import (
    GetParticipantsRequest,JoinChannelRequest,
    LeaveChannelRequest  # 退出群聊/频道用
)

from telethon.tl.functions.photos import (
    UploadProfilePhotoRequest,
    DeletePhotosRequest
)
from telethon.tl.types import (
    InputPhoto,
    PeerUser, PeerChat, PeerChannel,  # 用于指定删除的好友
    User,Channel, Chat,ChannelParticipantsSearch
)
from telethon.tl.types import InputPeerUser,InputPeerChat, InputPeerChannel
from utils import parse_status
from proxy_handler import parse_proxy
from telethon.errors import (
    PeerIdInvalidError,
    ChannelPrivateError,
    UserNotMutualContactError,
    ChatAdminRequiredError
)
from telethon.tl.functions.messages import ReadHistoryRequest,DeleteMessagesRequest,ImportChatInviteRequest
from telethon.errors import PeerIdInvalidError, FloodWaitError, InputUserDeactivatedError,UsernameOccupiedError, UsernameInvalidError,FloodWaitError,RPCError
from socks import GeneralProxyError
import functools

import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),                 # 控制台输出
        logging.FileHandler("account_tdata.log", encoding="utf-8")  # 写入文件
    ]
)
logger = logging.getLogger(__name__)
ACCOUNT_HANDLER_CACHE = {}

# 全局缓存配置（生产环境建议替换为Redis）
CONTACT_CACHE = {}       # 联系人缓存：key=账号ID_tdata路径, value={timestamp, data}
GROUP_CACHE = {}         # 群组缓存：key=账号ID_tdata路径, value={timestamp, data}
CACHE_EXPIRE = 300       # 缓存有效期（秒）- 5分钟
MAX_MESSAGE_LIMIT = 200  # 单次获取消息最大数量（避免数据过载）

class TelegramAccountHandler:
    _tdesk_cache = {}  # 缓存，避免重复解密 tdata
    
    def __init__(self, tdata_path, api_id, api_hash, proxy_str=None):
        self.tdata_path = tdata_path
        self.api_id = api_id
        self.api_hash = api_hash
        self.proxy_str = proxy_str
        self._lock = asyncio.Lock()  # 异步锁确保缓存操作安全
       
        # 不直接初始化session_cache，而是在首次使用时检查
        if not hasattr(self, 'session_cache'):
            self.session_cache = {
                "client": None,
                "is_connected": False,
            }
            self.loop = asyncio.get_event_loop() # 绑定当前进程的事件循环
    
    async def _initialize(self):
        """初始化账号信息"""
        result = {"status": True, "message": ""}
       
        return result    
        
    def _get_client_params(self):
        """获取 Telethon 客户端参数"""
        session_path = self.tdata_path
        proxy_info = None

        # 配置代理
        if self.proxy_str:
            proxy = parse_proxy(self.proxy_str)
            proxy_info = proxy
            proxy_conf = (
                proxy["protocol"],
                proxy["ip"],
                proxy["port"],
                True,
                proxy.get("username"),
                proxy.get("password")
            ) if proxy.get("username") else (
                proxy["protocol"],
                proxy["ip"],
                proxy["port"]
            )
        else:
            proxy_conf = None

        # 如果 session 已经存在，直接用 Telethon

        return {
            "session": session_path,
            "api_id": self.api_id,
            "api_hash": self.api_hash,
            "proxy": proxy_conf
        }, proxy_info
        

        
    async def set_online(self):
        """建立长连接并缓存客户端实例，支持自动重建 session"""
        async with self._lock:
            client = self.session_cache.get("client")
    
            # 复用已连接 client
            if client and client.is_connected():
                self.session_cache["is_connected"] = True
                return {
                    "status": True,
                    "message": "已处于在线状态",
                    "data": {"account_status": "正常", "account_status_desc": "登录成功"}
                }
    
            # 尝试重连已断开 client
            if client and not client.is_connected():
                try:
                    await client.connect()
                    if await client.is_user_authorized():
                        self.session_cache["client"] = client
                        self.session_cache["is_connected"] = True
                        return {
                            "status": True,
                            "message": "重新连接成功并保持长连接",
                            "data": {"account_status": "正常", "account_status_desc": "重新登录成功"}
                        }
                    else:
                        await client.disconnect()
                        self.session_cache["client"] = None
                        self.session_cache["is_connected"] = False
                except Exception:
                    self.session_cache["client"] = None
                    self.session_cache["is_connected"] = False
    
            # 没有可用 client 或需要重新生成 session
            client_params, proxy_info = self._get_client_params()
    
            async def create_client():
                """创建并连接 TelegramClient"""
                new_client = TelegramClient(
                    client_params["session"],
                    client_params["api_id"],
                    client_params["api_hash"],
                    proxy=client_params.get("proxy"),
                    connection_retries=1,
                    timeout=10,
                    sequential_updates=True,
                    loop=self.loop
                )
                await new_client.connect()
                if not await new_client.is_user_authorized():
                    await new_client.disconnect()
                    raise Exception("账号未授权")
                self.session_cache["client"] = new_client
                self.session_cache["is_connected"] = True
                return new_client
    
            try:
                return {
                    "status": True,
                    "message": "登录成功并保持长连接",
                    "data": {"account_status": "正常", "account_status_desc": "登录成功"}
                } if await create_client() else {}
    
            except Exception as e:
                err_msg = str(e)
    
                # session 被多 IP 使用 -> 删除旧 session 并重建
                if "authorization key" in err_msg and "used under two different IP addresses" in err_msg:
                    try:
                        session_file = client_params["session"]
                        if os.path.exists(session_file):
                            os.remove(session_file)
                    except Exception:
                        pass
    
                    # 立即重新生成 client
                    try:
                        await create_client()
                        return {
                            "status": True,
                            "message": "旧 session 被占用，已重建新 session 并登录成功",
                            "data": {"account_status": "正常", "account_status_desc": "会话被重建，登录成功"}
                        }
                    except Exception as e2:
                        return {
                            "status": False,
                            "message": f"重建 session 失败: {e2}",
                            "data": {"account_status": "异常", "account_status_desc": f"重建 session 失败: {e2}"}
                        }
    
                # 代理异常识别
                if "Connection to Telegram failed" in err_msg:
                    return {
                        "status": False,
                        "message": f"代理异常: {err_msg}",
                        "data": {"account_status": "代理异常", "account_status_desc": f"代理异常: {err_msg}"}
                    }
    
                # 其他异常
                return {
                    "status": False,
                    "message": f"登录失败: {err_msg}",
                    "data": {"account_status": "异常", "account_status_desc": f"登录失败: {err_msg}"}
                }

    async def set_offline(self):
        """断开连接并清理缓存"""
        async with self._lock:
            # 断开连接
            client = self.session_cache.get("client")
            if client and client.is_connected():
                try:
                    await client.send(UpdateStatusRequest(offline=True))
                    await client.disconnect()
                except Exception as e:
                    print(f"断开连接警告: {e}")

            self.session_cache["client"] = None
            # 重置状态
            self.session_cache["is_connected"] = False
            
            return {
                "status": True,
                "message": "已下线",
                "data": {"account_status": '退出',"account_status_desc":"已退出"}
            }


    async def _get_entity_type(self, entity):
        """判断实体类型（普通群组/超级群组/频道）"""
        if isinstance(entity, User):
            return "user"
        elif  isinstance(entity, Channel):
            if entity.megagroup:
                return "megagroup"  # 超级群组
            else:
                return "channel"    # 频道
        elif isinstance(entity, Chat):
            return "chat"          # 普通群组
        return "unknown"           # 未知类型
        
    async def _get_input_peer(self, entity, entity_type):
        """根据实体类型获取对应的InputPeer"""
        if entity_type == "user":
            return InputPeerUser(entity.id, entity.access_hash)
        elif entity_type == "chat":
            return InputPeerChat(entity.id)
        elif entity_type in ["megagroup", "channel"]:
            return InputPeerChannel(entity.id, entity.access_hash)
        raise ValueError(f"不支持的实体类型: {entity_type}")
    # 定义一个账号状态处理的装饰器
    def handle_account_status(func):
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs):
            # 初始化结果结构
            result = {"status": False, "message": "", "data": {}}
            
            try:
                # 检查缓存连接
                client = self.session_cache.get("client")
                '''
                if not client or not self.session_cache["is_connected"]:
                    result["message"] = "请先调用上线功能"
                    result["data"]["is_connected"] = False
                    result["data"]["account_status"] = "未连接"
                    result["data"]["account_status_desc"] = "未登录，请先登录"
                    return result
                '''  
                if not client or not self.session_cache["is_connected"]:
                    # 尝试自动重连
                    retry_result = await self.set_online()
                    if not retry_result["status"]:
                        result["message"] = f"登录失败：请先调用上线。原因：{retry_result['message']}"
                        result["data"]["is_connected"] = False
                        result["data"]["account_status"] = "异常"
                        result["data"]["account_status_desc"] = "登录失败，先登录"
                        return result
                    client = self.session_cache["client"]
                
                try:
                    if not  client.is_connected():
                        result["message"] = "连接已失效，请重新调用上线"
                        result["data"]["is_connected"] = False
                        result["data"]["account_status"] = "异常"
                        result["data"]["account_status_desc"] = "登录失败，先登录"
                        return result
                except Exception as e:
                    result["message"] = f"连接校验失败: {str(e)}"
                    result["data"]["is_connected"] = False
                    result["data"]["account_status"] = "异常"
                    result["data"]["account_status_desc"] = "连接异常"
                    return result
                    
                logger.info(f"[client] 状态:{client}")
                # 检查账号是否被注销
                try:
                    # 获取当前用户信息
                    
                    current_user = await client.get_me()
                    if getattr(current_user, 'restricted', False):
                        restriction_reason = getattr(current_user, 'restriction_reason', [])
                        if restriction_reason:
                            # 冻结（限制部分功能）
                            reason_text = ', '.join(
                                [r.reason if hasattr(r, 'reason') else str(r) for r in restriction_reason]
                            ) or "未知原因"
                            result["data"]["account_status"] = "冻结"
                            result["data"]["account_status_desc"] = "账号受限，部分功能不可用"
                            result["data"]["reason"] = reason_text
                            result["status"] = False
                            result["message"] = f"账号被冻结，原因: {reason_text}"
                            await client.disconnect()
                            return result
                        else:
                            # 封号（彻底封禁）
                            result["data"]["account_status"] = "封号"
                            result["data"]["account_status_desc"] = "账号已被封禁"
                            result["status"] = False
                            result["message"] = "账号已被封禁"
                            await client.disconnect()
                            return result
                    try:
                        await client(UpdateProfileRequest())  # 不传参数，不会修改资料
                    except RPCError as rpc_err:
                        if "FROZEN_METHOD_INVALID" in str(rpc_err):
                            result["data"]["account_status"] = "冻结"
                            result["data"]["account_status_desc"] = "账号被冻结"
                            result["data"]["reason"] = "FROZEN_METHOD_INVALID"
                            result["data"]["freeze_type"] = "rpc_error"
                            result["status"] = False
                            result["message"] = "账号被冻结（RPC限制）"
                            await client.disconnect()
                            return result
                    # 调用原始方法，传入 client 和 current_user
                    safe_kwargs = {k: v for k, v in kwargs.items() if k not in ["client", "current_user", "result"]}
                    result = await func(
                        self,
                        *args,
                        client=client,
                        current_user=current_user,
                        result=result,
                        **safe_kwargs
                    )
                    
                except InputUserDeactivatedError:
                    # 明确识别账号被注销或删除的情况
                    result["data"]["account_status"] = "注销"
                    result["data"]["account_status_desc"] = "账号已被注销"
                    result["status"] = False
                    result["message"] = "账号已被注销"
                except Exception as e:
                    result["status"] = False
                    err_msg = str(e)

                    # === 新增错误分类 ===
                    # Telegram session key 被多 IP 使用
                    if "authorization key" in err_msg and "used under two different IP addresses" in err_msg:
                        return {
                            "status": False,
                            "message": f"会话失效：{err_msg}",
                            "data": {"account_status": "会话失效", "account_status_desc": "session已在其他IP使用，请重新生成会话"}
                        }
                    elif "Connection to Telegram failed" in err_msg:
                   
                        result["data"]["account_status"] = "代理异常"
                        result["data"]["account_status_desc"] = "代理无法连接"
                        result["message"] = f"网络异常: {err_msg}"
                    else:
                    
                        result["data"]["account_status"] = "异常"
                        result["data"]["account_status_desc"] = f"获取用户信息失败: {err_msg}"
                        result["message"] = err_msg
    
            except Exception as e:
                result["status"] = False
                result["data"]["account_status"] = "异常"
                result["data"]["account_status_desc"] = "获取用户信息失败"
                result["message"] = f"获取失败: {str(e)}"
            '''
            finally:
                # 确保断开连接
                if hasattr(self, 'client') and self.client and self.client.is_connected():
                    try:
                        await self.client.disconnect()
                    except:
                        pass
            '''
            return result
        return wrapper
    # 在TelegramAccountHandler类中添加
    #获取    获取所有群组/频道列表，包含头像URL和未读消息数#
    @handle_account_status
    async def get_groups(self, client=None, current_user=None, result=None, force_refresh=False):
        """
        获取所有群组/频道列表（优化版）
        :param force_refresh: 是否强制刷新（跳过缓存）
        """
        start_time = time.time()
        # 1. 构建缓存Key（唯一标识当前账号的群组缓存）
        cache_key = f"groups_{current_user.id}_{self.tdata_path}"
        
        # 2. 检查缓存（非强制刷新时）
        if not force_refresh and cache_key in GROUP_CACHE:
            cache_data = GROUP_CACHE[cache_key]
            if time.time() - cache_data["timestamp"] < CACHE_EXPIRE:
                cache_data["data"]["message"] += "（来自缓存）"
                cache_data["data"]["data"]["load_time"] = f"{int((time.time() - start_time)*1000)}ms"
                return cache_data["data"]

        # 3. 初始化结果结构
        result = {
            "status": False, 
            "message": "", 
            "data": {
                "groups": [],
                "load_time": "0ms"  # 新增：加载耗时统计
            }
        }
        try:
            path_parts = os.path.normpath(self.tdata_path).split(os.sep)
            uploads_index = path_parts.index("uploads")
            # 拼接基础路径: .../public/uploads/
            base_uploads_path = os.sep.join(path_parts[:uploads_index + 1])
            avatar_base_dir = os.path.join(base_uploads_path, "groupimg")
            
            # 确保目录存在并设置权限
            os.makedirs(avatar_base_dir, exist_ok=True)
            os.chmod(avatar_base_dir, 0o755)
            
            # 获取绝对路径的规范形式
            avatar_base_dir = os.path.abspath(avatar_base_dir)
            logger.info(f"群组头像存储目录：{avatar_base_dir}")
            
            groups = []
            # 4. 遍历对话（仅筛选群组/频道，减少冗余处理）
            async for dialog in client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    # 4.1 从dialog直接提取信息（无需额外调用get_entity）
                    entity = dialog.entity
                    group_id = dialog.id
                    avatar_filename = f"group_{group_id}.jpg"
                    avatar_abs_path = os.path.join(avatar_base_dir, avatar_filename)
                    
                    avatar_url = None
                    # 只有当文件不存在或强制刷新时才下载
                    if (not os.path.exists(avatar_abs_path)) or force_refresh:
                        if hasattr(entity, 'photo') and entity.photo:
                            try:
                                # 下载小尺寸头像
                                photo_bytes = await client.download_profile_photo(
                                    entity, 
                                    file=bytes,
                                    download_big=False
                                )
                                if photo_bytes:
                                    # 保存到绝对路径
                                    with open(avatar_abs_path, "wb") as f:
                                        f.write(photo_bytes)
                                    os.chmod(avatar_abs_path, 0o644)
                                    avatar_url = avatar_abs_path
                                    logger.info(f"已保存头像: {avatar_abs_path}")
                            except Exception as e:
                                logger.warning(f"下载群组{group_id}头像失败: {str(e)}")
                                avatar_url = None
                    else:
                        # 直接使用已存在的本地文件
                        avatar_url = avatar_abs_path
                        logger.debug(f"使用本地头像: {avatar_abs_path}")
                        
                    web_root_path = os.path.join(os.path.dirname(base_uploads_path), "")  # 到public目录
                    avatar_web_path = os.path.relpath(avatar_abs_path, web_root_path).replace(os.sep, '/')
                    avatar_web_path = f"/{avatar_web_path}"  # 确保以/开头    
                    
                    # 4.2 精简字段：只返回前端必需的信息
                    group_info = {
                        "id": dialog.id,
                        "title": dialog.title,
                        "type": "channel" if dialog.is_channel else "group",
                        "unread_count": dialog.unread_count,
                        "last_msg": "",
                        "member_count": entity.participants_count if hasattr(entity, 'participants_count') else 0,
                        "can_click": True,
                        "avatar_web_path": avatar_web_path,
                        "is_megagroup": entity.megagroup if isinstance(entity, Channel) else False  # 补充超级群组标识
                    }
                    
                    # 4.3 处理最后一条消息（限制长度，避免大文本传输）
                    if dialog.message:
                        if dialog.message.text:
                            group_info["last_msg"] = dialog.message.text[:50]  # 只保留前50字符
                        else:
                            group_info["last_msg"] = "[非文本消息]"
                    
                    groups.append(group_info)
            
            # 5. 计算耗时
            load_time = int((time.time() - start_time) * 1000)
            # 6. 填充结果
            result["status"] = True
            result["message"] = f"成功获取{len(groups)}个群组/频道（耗时{load_time}ms）"
            result["data"]["groups"] = groups
            result["data"]["load_time"] = f"{load_time}ms"
            
            # 7. 更新缓存
            GROUP_CACHE[cache_key] = {
                "timestamp": time.time(),
                "data": result
            }
            
        except Exception as e:
            result["message"] = f"获取群组失败: {str(e)}"
        
        return result
        
    #屏蔽并删除用户（机器人直接删除）#   
    @handle_account_status
    async def block_user(self, user_id, client=None, current_user=None,result=None):
        result = {"status": False, "message": ""}
        try:
            # 确保 user_id 为整数
            try:
                user_id_int = int(user_id)
            except ValueError:
                result["message"] = f"无效的用户ID: {user_id}"
                return result
    
            # 获取用户实体
            try:
                entity = await client.get_entity(user_id_int)
                if not isinstance(entity, User):
                    result["message"] = f"ID {user_id} 不是有效的用户实体"
                    return result
                if getattr(entity, "deleted", False):
                    result["message"] = f"用户 {user_id} 已注销"
                    return result
            except (PeerIdInvalidError, InputUserDeactivatedError):
                result["message"] = f"找不到该用户或已注销，ID: {user_id}"
                return result
            except Exception as e:
                result["message"] = f"获取用户信息失败: {str(e)}"
                return result
    
            # 构造 InputPeerUser
            try:
                user_peer = InputPeerUser(user_id=entity.id, access_hash=entity.access_hash)
            except AttributeError as e:
                result["message"] = f"构造用户实体失败: {str(e)}"
                return result
    
            # 处理机器人
            if getattr(entity, "bot", False):
                try:
                    await client(DeleteContactsRequest(id=[user_peer]))
                except Exception as e:
                    result["message"] = f"删除机器人失败: {str(e)}"
                    return result
    
                try:
                    await client.delete_dialog(user_peer)
                except Exception as e:
                    result["message"] = f"已删除机器人，但清理聊天对话失败: {str(e)}"
                    result["status"] = True
                    return result
    
                result["status"] = True
                result["message"] = f"已删除机器人 {user_id} 并清理聊天记录"
    
            else:
                # 普通用户 → 屏蔽
                try:
                    await client(BlockRequest(id=user_peer))
                except FloodWaitError as e:
                    result["message"] = f"操作过于频繁，请等待 {e.seconds} 秒后再试"
                    return result
                except Exception as e:
                    result["message"] = f"屏蔽操作失败: {str(e)}"
                    return result
    
                # 删除联系人
                try:
                    await client(DeleteContactsRequest(id=[user_peer]))
                except Exception as e:
                    result["message"] = f"屏蔽成功，但删除联系人失败: {str(e)}"
                    result["status"] = True
                    return result
    
                # 删除聊天记录
                try:
                    await client.delete_dialog(user_peer)
                except Exception as e:
                    result["message"] = f"屏蔽并删除联系人成功，但清理聊天对话失败: {str(e)}"
                    result["status"] = True
                    return result
    
                result["status"] = True
                result["message"] = f"已成功屏蔽并删除用户 {user_id} 并清理聊天记录"
    
        except Exception as e:
            result["message"] = f"操作失败: {str(e)}"
        return result
    #删除用户或机器人，并清理聊天记录和对话#    
    @handle_account_status
    async def deleteUser(self, user_id, client=None, current_user=None,result=None):
        """删除用户或机器人，并清理聊天记录和对话"""
        result = {"status": False, "message": ""}
        try:
           
            # 确保 user_id 为整数
            try:
                user_id_int = int(user_id)
            except ValueError:
                result["message"] = f"无效的用户ID: {user_id}"
                return result
    
            # 获取用户实体
            try:
                entity = await client.get_entity(user_id_int)
                if not hasattr(entity, "access_hash"):
                    result["message"] = f"无法获取用户 access_hash，ID: {user_id}"
                    return result
                user_peer = InputPeerUser(entity.id, entity.access_hash)
            except PeerIdInvalidError:
                result["message"] = f"找不到该用户（可能没有任何对话），ID: {user_id}"
                return result
            except Exception as e:
                result["message"] = f"获取用户信息失败: {str(e)}"
                return result
    
            # 删除联系人
            try:
                await client(DeleteContactsRequest(id=[user_peer]))
            except Exception as e:
                result["message"] = f"删除联系人失败: {str(e)}"
                return result
    
            # 删除聊天记录并彻底移除对话
            try:
                await client.delete_dialog(user_peer)
            except Exception as e:
                # 仅记录错误，不影响最终成功状态
                result["message"] = f"已删除联系人，但清理对话失败: {str(e)}"
                result["status"] = True
                return result
    
            # 成功
            result["status"] = True
            if getattr(entity, "bot", False):
                result["message"] = f"已删除机器人 {user_id} 并清理聊天记录"
            else:
                result["message"] = f"已删除用户 {user_id} 并清理聊天记录"
    
        except Exception as e:
            result["message"] = f"操作失败: {str(e)}"
    
        return result
    #删除聊天记录#   
    @handle_account_status
    async def delete_chat_history(self, target_id, is_private=True, client=None, current_user=None,result=None):
        """删除聊天记录"""
        result = {"status": False, "message": ""}
        try:
           
            # 处理用户ID - 确保是整数类型
            try:
                user_id = int(target_id)
                try_ids = [user_id, abs(user_id)]  # 尝试可能的ID形式
                
                entity = None
                for uid in try_ids:
                    try:
                        entity = await client.get_entity(uid)
                        if hasattr(entity, 'user'):  # 确认是用户实体
                            break
                    except Exception as e:
                        continue
    
                if not entity:
                    result["message"] = f"无法找到用户ID为 {target_id} 的用户"
                  
                    return result
    
                # 批量获取并删除消息
                messages = []
                async for msg in client.iter_messages(entity):
                    messages.append(msg.id)
                    
                    # 每100条消息一批进行删除（Telegram API限制）
                    if len(messages) >= 100:
                        # 使用正确的函数调用方式
                        await client(DeleteMessagesRequest(
                            id=messages,
                            revoke=True  # 撤回消息（对双方都生效）
                        ))
                        messages = []
                
                # 删除剩余的消息
                if messages:
                    await client(DeleteMessagesRequest(
                        id=messages,
                        revoke=True
                    ))
                
                result["status"] = True
                result["message"] = f"已删除与用户ID {target_id} 的所有聊天记录"
                
            except ValueError:
                result["message"] = f"无效的用户ID格式: {target_id}，必须是整数"
            except Exception as e:
                result["message"] = f"删除记录失败: {str(e)}"
            
                    
        except Exception as e:
            result["message"] = f"操作失败: {str(e)}"
        return result
    #获取所有私聊对象（包括未保存到通讯录的临时会话）#     
    @handle_account_status    
    async def get_contacts(self, client=None, current_user=None,result=None):
        """
        获取所有私聊对象（包括未保存到通讯录的临时会话）
        :param filter_unread: 是否只返回有未读消息的对象（默认False）
        """
        result = {
            "status": False, 
            "message": "", 
            "data": {
                "private_chats": [],  # 所有私聊对象
                "unread_chats": [],   # 仅包含有未读消息的私聊对象
                "total_unread": 0     # 私聊未读消息总数
            }
        }
        filter_unread=False
        try:
           
            
            private_chats = []
            unread_chats = []
            total_unread = 0
            
            # 遍历所有对话，筛选出私聊类型
            async for dialog in client.iter_dialogs():
                # 判断是否为私聊（排除群组、频道）
                if dialog.is_user and not dialog.is_group and not dialog.is_channel:
                    # 获取用户详细信息
                    user = await client.get_entity(dialog.id)
                    # 使用user实体获取头像（符合逻辑的处理方式）
                    avatar_url = None
                    '''
                    try:
                        if user.photo:  # 先检查是否有头像
                            photo_bytes = await client.download_profile_photo(user, file=bytes)
                            if photo_bytes:
                                import base64
                                avatar_url = f"data:image/jpeg;base64,{base64.b64encode(photo_bytes).decode()}"
                    except:
                        avatar_url = None     
                    '''    
                    chat_info = {
                        "id": user.id,
                        "username": user.username or "",
                        "first_name": user.first_name or "",
                        "last_name": user.last_name or "",
                        "title": dialog.title,
                        "unread_count": dialog.unread_count,  # 未读消息数
                        "has_unread": dialog.unread_count > 0,  # 新增：是否有未读
                        "avatar_url": avatar_url,  # 头像URL
                        "is_contact": user.contact
                    }
                    
                    # 累计未读总数
                    if dialog.unread_count > 0:
                        total_unread += dialog.unread_count
                        unread_chats.append(chat_info)
                    
                    # 根据筛选条件决定是否添加到总列表
                    if not filter_unread or (filter_unread and dialog.unread_count > 0):
                        private_chats.append(chat_info)
            
            result["status"] = True
            result["data"]["private_chats"] = private_chats
            result["data"]["unread_chats"] = unread_chats
            result["data"]["total_unread"] = total_unread
            result["message"] = (
                f"获取私聊对象成功，共 {len(private_chats)} 个，"
                f"其中 {len(unread_chats)} 个有未读消息，总计 {total_unread} 条未读"
            )
            
        except Exception as e:
            result["message"] = f"获取私聊对象失败: {str(e)}"
        return result
    #获取指定聊天的新消息#   
    @handle_account_status
    async def get_new_messages(self, target_id=None,  last_msg_id=0, timeout=3, client=None, current_user=None,result=None):
        """获取指定聊天的新消息"""
        result = {"status": False, "message": "", "data": {"messages": []}}
        
        try:
            
            # 转换目标ID格式
            target_id = int(target_id)
            if target_id > 0:
                target_id = -target_id  # 群组ID通常为负数
            
            # 获取实体
            entity = await client.get_entity(target_id)
            
            # 获取新消息（ID大于last_msg_id的消息）
            messages = []
            async for msg in client.iter_messages(entity, min_id=last_msg_id, limit=None):
                # 注意：使用 msg.out 而非 msg.outgoing
                messages.append({
                    "id": msg.id,
                    "text": msg.text,
                    "date": msg.date.isoformat(),
                    "sender_id": msg.sender_id,
                    "is_outgoing": msg.out,  # 修正属性名
                    "media": "存在" if msg.media else "不存在"
                })
            
            
            result["status"] = True
            result["message"] = f"成功获取 {len(messages)} 条新消息"
            result["data"]["messages"] = messages
            
        except Exception as e:
            result["message"] = f"获取消息失败: {str(e)}"
            
                
        return result   
    # 在TelegramAccountHandler类中添加
    
    # 在TelegramAccountHandler类中添加
    @handle_account_status
    async def send_messages(self, group_ids, message_type, text=None, forward_id=None, media_paths=None, delay=1, feedback_type=None,first_msg_id=0, client=None, current_user=None,result=None):
        """
        发送消息到指定群组（适配普通群组/超级群组/频道）
        :param group_ids: 群组ID列表
        :param message_type: 消息类型 text/forward/image/voice/image_text
        :param text: 文本内容（text类型需要）
        :param forward_id: 转发消息ID（forward类型需要）
        :param media_paths: 媒体文件路径列表（image/voice类型需要）
        :param delay: 发送延迟（秒）
        :param feedback_type: 回复类型
        :return: 发送结果
        """
        if "success" not in result["data"]:
            result["data"]["success"] = []
        if "failed" not in result["data"]:
            result["data"]["failed"] = []
        if "debug" not in result["data"]:
            result["data"]["debug"] = []
        if "warning" not in result["data"]:
            result["data"]["warning"] = ""
        
        try:
            logger.info(
                f"[send_messages] 开始执行，群组列表: {group_ids}, 消息类型: {message_type}, "
                f"当前账号ID: {current_user.id if current_user else '未知'}"
            )
            # 处理group_ids输入格式，支持逗号分隔字符串或列表
            if isinstance(group_ids, str):
                # 分割逗号并去除空格
                original_group_ids = group_ids 
                group_ids = [id.strip() for id in group_ids.split(',') if id.strip()]
                logger.debug(f"[send_messages] 字符串群组ID转换为列表: 原始='{original_group_ids}', 转换后={group_ids}")
            
            # 去重处理
            unique_group_ids = list(set(group_ids))
            if len(unique_group_ids) < len(group_ids):
                result["data"]["warning"] = f"检测到重复群组ID，已自动去重，原{len(group_ids)}个，去重后{len(unique_group_ids)}个"
                group_ids = unique_group_ids
                
            # 获取当前账号信息
            if not current_user:
                raise Exception("未获取到当前账号信息（current_user为空）")
            current_user_id = current_user.id
            
            for group_identifier in group_ids:
                group_id = None
                is_member=False
                try:
                    # 确保group_identifier是字符串类型，便于处理
                    group_str = str(group_identifier).strip()
                    # 清除所有可能的转义字符和引号
                    group_str_clean = group_str.replace('\\', '').replace('"', '').replace("'", "")
                    is_telegram_link = False
                    
                    # 针对命令行传递的链接格式进行增强识别
                    # 检查是否包含t.me或telegram.me，无论位置和协议
                    if 't.me' in group_str_clean or 'telegram.me' in group_str_clean:
                        is_telegram_link = True
                    # 检查是否是纯数字ID
                    is_numeric_id = group_str_clean.lstrip('-').isdigit()
                    
                    # 调试信息
                    result["data"]["debug"].append(
                        f"处理标识符: {group_identifier}, 清理后: {group_str_clean}, "
                        f"识别为链接: {is_telegram_link}, 识别为数字ID: {is_numeric_id}"
                    )
                    normalized_link = None
                
                    # 最宽松的链接判断：只要包含t.me就视为链接
                    if 't.me' in group_str_clean:
                        is_telegram_link = True
                        # 标准化链接
                        if not group_str_clean.startswith(('http://', 'https://')):
                            normalized_link = f"https://{group_str_clean}"
                        else:
                            normalized_link = group_str_clean
                    # 处理群链接
                    if is_telegram_link:
                        try:
                            # 私密邀请链接 (+号开头)
                            if "+" in normalized_link:
                                hash_part = normalized_link.split("+")[-1]
                                try:
                                    # 尝试直接获取实体（账号已加入的情况）
                                    entity = await client.get_entity(normalized_link)
                                except ValueError:
                                    # 未加入，使用 ImportChatInviteRequest 加入
                                    updates = await client(ImportChatInviteRequest(hash_part))
                                    if updates.chats and len(updates.chats) > 0:
                                        entity = updates.chats[0]
                                    else:
                                        raise ValueError("加入私密群组后无法获取实体")
                            
                                group_id = entity.id
                                entity_type = await self._get_entity_type(entity)
                                is_member = True
                              
                            else:
                            # 公开群组/频道 尝试获取实体
                                entity = await client.get_entity(normalized_link)
                                entity_type = await self._get_entity_type(entity)
                                is_member = await self._check_group_membership(entity, current_user_id, entity_type,client)
                                
                                # 如果不是成员，加入群组
                                if not is_member:
                                    # 修复：使用正确的方法加入群组（根据TelegramClient库版本选择）
                                    await client(JoinChannelRequest(entity))
                                    
                                    result["data"]["debug"].append(f"成功加入群组: {normalized_link}")
                                    await asyncio.sleep(5)  # 延长等待时间，确保加入成功
                                    
                                    # 重新获取实体以获取最新信息
                                    entity = await client.get_entity(normalized_link)
                                    # 从实体中获取群组ID
                                    group_id = entity.id
                                    
                                    result["data"]["debug"].append(f"加入后获取群组ID: {group_id}")
                                    
                                    # 重新检查成员身份
                                    is_member = await self._check_group_membership(entity, current_user_id, await self._get_entity_type(entity),client)
                                    if not is_member:
                                        raise PermissionError(f"加入群组 {normalized_link} 后仍无法获取成员身份")
                                else:
                                    # 如果已是成员，直接获取群组ID
                                    group_id = entity.id
                                    result["data"]["debug"].append(f"已是群组成员，群组ID: {group_id}")
                                
                        except Exception as e:
                            error_msg = f"处理链接 {normalized_link} 时出错: {str(e)}"
                            result["data"]["debug"].append(error_msg)
                            raise PermissionError(error_msg)
                    
                    # 处理ID格式
                    elif is_numeric_id:
                        try:
                            group_id = int(group_str_clean)
                        except ValueError:
                            raise ValueError(f"无效的群组ID: {group_identifier}")
                            
                        # 转换群组ID为正确格式
                        #if group_id > 0:
                        #    group_id = -group_id
                        
                        # 查找对话
                        dialog_match = None
                        async for dialog in client.iter_dialogs():
                            if dialog.id == group_id or abs(dialog.id) == group_id:
                                dialog_match = dialog
                                group_id = dialog.id
                                break
                        
                        if not dialog_match:
                            raise PermissionError(f"群组不在对话列表中，可能未加入: {group_id}")
                        
                        # 获取实体
                        try:
                            entity = await client.get_entity(group_id)
                        except Exception as e:
                            raise PermissionError(f"无法获取群组信息: {str(e)}")
                
                    else:
                        raise ValueError(f"无效的群组标识符: {group_identifier}，既不是有效的ID也不是链接")
                    
                    
                
                    # 获取实体类型和输入对等体
                    entity_type = await self._get_entity_type(entity)
                    input_peer = await self._get_input_peer(entity, entity_type)
                    # 检查成员身份
                    if entity_type == "user":
                        is_member = True   # 私聊不需要检查
                    else:
                        is_member = await self._check_group_membership(entity, current_user_id, entity_type,client)
                        if not is_member:
                            raise PermissionError(f"账号不在该{entity_type}中，无法发送消息")

                    
                    
                    # 检查发送权限
                    if entity_type == "channel" and not entity.broadcast:
                        permissions = await client.get_permissions(entity, current_user)
                        if not permissions.send_messages:
                            raise PermissionError("没有在频道发送消息的权限")

                    # 处理回复消息ID
                    reply_to_msg_id = None
                    if feedback_type == "forward":
                        if first_msg_id > 0:
                            reply_to_msg_id = first_msg_id
    
                    # 发送消息
                    message_id = None
                    
                    # 根据消息类型和群组类型发送消息
                    if message_type == "text":
                        sent_msg =  await client.send_message(
                            input_peer, 
                            text,
                            reply_to=reply_to_msg_id
                        )
                        message_id = sent_msg.id

                        
                    elif message_type == "image":
                        for path in media_paths:
                            sent_msg = await client.send_file(
                                input_peer, 
                                path, 
                                caption=text or "",
                                reply_to=reply_to_msg_id
                            )
                            message_id = sent_msg.id
                    elif message_type == "image_text":
                        if entity_type == "channel":
                            # 频道图片消息处理
                            for path in media_paths:
                                sent_msg = await client.send_file(
                                    input_peer, 
                                    path, 
                                    caption=text or ""
                                )
                                message_id = sent_msg.id
                        else:
                            # 群组图片消息处理（支持回复）
                            for path in media_paths:
                                sent_msg = await client.send_file(
                                    input_peer, 
                                    path, 
                                    caption=text or "",
                                    reply_to=reply_to_msg_id
                                )
                                message_id = sent_msg.id
                            

                            
                    # 记录成功
                    result["data"]["success"].append({
                        "group_id": group_id,
                        "group_link": group_identifier if str(group_identifier).startswith(('http', 't.me')) else None,
                        "type": entity_type,
                        "message": "发送成功",
                        "message_id": message_id 
                    })
                    
                except Exception as e:
                    # 记录失败（包含类型信息）
                    result["data"]["failed"].append({
                        "group_id": group_id,
                        "recognized_as_link": is_telegram_link,
                        "group_identifier": group_identifier,
                        "type": entity_type if 'entity_type' in locals() else "unknown",
                        "message": str(e)
                    })
                    
            
            # 整理结果
            result["status"] = True
            result["message"] = f"发送完成，成功{len(result['data']['success'])}个，失败{len(result['data']['failed'])}个{result['data']['failed']}"
        
            
        except Exception as e:
            result["message"] = f"发送消息失败: {str(e)}"
            
        logger.info(
            f"[send_messages] 返回结果: status={result['status']}, message='{result['message']}', "
            f"success_cnt={len(result['data']['success'])}, failed_cnt={len(result['data']['failed'])}"
        )   
        return result 
    #检查用户是否为群组/频道成员#    
    async def _check_group_membership(self, entity, user_id, entity_type,client):
        """检查用户是否为群组/频道成员"""
        try:
            if entity_type == "chat":  # 普通群组
                # 获取普通群组成员列表
                participants = await client.get_participants(entity, limit=200)  # 限制获取数量避免性能问题
                return any(participant.id == user_id for participant in participants)
                
            elif entity_type in ["megagroup", "channel"]:  # 超级群组/频道
                # 超级群组和频道使用get_permissions检查是否为成员
                try:
                    # 如果是成员，能获取到权限信息；非成员会抛出异常
                    await client.get_permissions(entity, user_id)
                    return True
                except Exception:
                    return False
                    
            return False
        
        except Exception as e:
            self.logger.error(f"检查成员身份失败: {str(e)}")
            # 对于超级群组，出现权限错误通常意味着不是成员
            return False    
    # --------------------------
    # 一键删除所有好友
    # --------------------------
    @handle_account_status
    async def delete_all_contacts(self, client=None):
        """删除账号中所有好友（谨慎使用）"""
        result = {"status": False, "message": "", "data": {}}
        
        try:

            # 获取所有联系人
            contacts = await client(GetContactsRequest(hash=0))
            total = len(contacts.users)
            deleted = 0
            
            if total == 0:
                result["message"] = "没有好友可删除"
                result["status"] = True
                return result
            
            # 逐个删除好友（Telegram API限制批量删除，需循环处理）
            for user in contacts.users:
                # 构造用户ID对象
                peer = PeerUser(user_id=user.id)
                # 调用删除接口
                await client(DeleteContactsRequest(id=[peer]))
                deleted += 1
                
            result["status"] = True
            result["message"] = f"删除完成，共处理 {total} 个好友，成功删除 {deleted} 个"
            result["data"]["total"] = total
            result["data"]["deleted"] = deleted
            
        except Exception as e:
            result["message"] = f"删除好友失败: {str(e)}"
                
        return result

    # --------------------------
    # 一键退出所有群聊/频道
    # --------------------------
    @handle_account_status
    async def leave_all_groups(self, client=None):
        """退出账号中所有群聊和频道（谨慎使用）"""
        result = {"status": False, "message": "", "data": {}}
        
        try:
           
            # 获取所有群聊和频道
            groups = []
            async for dialog in client.iter_dialogs(limit=None):
                # 旧版本中用 `dialog.entity` 的类型判断超级群/普通群
                # 1. 判断是否为频道（旧版本属性）
                is_channel = hasattr(dialog.entity, 'megagroup') and not dialog.entity.megagroup
                # 2. 判断是否为超级群（旧版本用 `megagroup` 属性）
                is_supergroup = hasattr(dialog.entity, 'megagroup') and dialog.entity.megagroup
                # 3. 判断是否为普通群聊（旧版本用 `title` 和 `id` 排除私聊）
                is_group = dialog.is_group  # 旧版本普通群聊的属性
                
                # 合并判断：包含普通群、超级群、频道（排除私聊）
                if (is_group or is_supergroup or is_channel) and not dialog.is_user:
                    groups.append(dialog)
            
            total = len(groups)
            left = 0
            failed = []
            if total == 0:
                result["message"] = "没有群聊/频道可退出"
                result["status"] = True
                return result
            
            # 逐个退出群聊/频道
            for group in groups:
                try:
                    if isinstance(group.entity, Chat):
                        # 普通群聊（小群）
                        result_api = await client.kick_participant(group.entity, 'me')
                        await client.delete_dialog(group.entity)
                        if result_api:
                            left += 1
                    elif isinstance(group.entity, Channel):
                        # 超级群 / 频道
                        result_api =await client(LeaveChannelRequest(group.entity))
                        #await self.client.delete_dialog(group.entity)
                        if result_api:
                            left += 1
                    else:
                        # 其他不支持的类型
                        failed.append({
                            "title": group.title,
                            "id": group.id,
                            "type": type(group.entity).__name__,
                            "error": "不支持的群聊类型"
                        })
                except Exception as e:
                    failed.append({
                        "title": group.title,
                        "id": group.id,
                        "type": type(group.entity).__name__,
                        "error": str(e)
                    })
            
          
            
            result["status"] = True
            result["message"] = f"退出完成，共处理 {total} 个群聊/频道，成功退出 {left} 个"
            result["data"]["total"] = total
            result["data"]["left"] = left
            result["data"]["failed"] = failed 
            
        except Exception as e:
            result["message"] = f"退出群聊失败: {str(e)}"
                
        return result

    # --------------------------
    # 退出所有其他登录设备
    # --------------------------
    @handle_account_status
    async def logout_other_sessions(self, client=None):
        """退出当前账号在其他设备的登录（保留当前会话）"""
        result = {"status": False, "message": "", "data": {}}
        
        try:
            
            # 获取所有登录授权（包括当前设备）
            authorizations = await client(GetAuthorizationsRequest())
            total = len(authorizations.authorizations)
            logged_out = 0
            
            if total <= 1:
                result["message"] = "没有其他设备登录"
                result["status"] = True
                return result
            
            # 遍历所有授权，只保留当前会话（排除当前设备）
            current_hash = authorizations.current_hash  # 当前会话的标识
            for auth in authorizations.authorizations:
                # 跳过当前设备的授权
                if auth.hash == current_hash:
                    continue
                # 撤销其他设备的授权
                await client(ResetAuthorizationRequest(hash=auth.hash))
                logged_out += 1
            
           
            
            result["status"] = True
            result["message"] = f"操作完成，共检测到 {total} 个登录设备，成功退出 {logged_out} 个"
            result["data"]["total_devices"] = total
            result["data"]["logged_out"] = logged_out
            
        except Exception as e:
            result["message"] = f"退出其他设备失败: {str(e)}"
                
        return result
        

    @handle_account_status
    async def get_account_info(self, client=None, current_user=None, result=None):
        """获取账号详细信息"""
        try:
            # 账号正常
            result["data"]["account_status"] = "正常"
            result["data"]["account_status_desc"] = "账号状态正常"
            result["status"] = True
            result["message"] = "账号状态正常"
     
            # 头像信息
            avatar_path = None
            try:
                if current_user.photo:  # 检查是否有头像
                    # 创建保存头像的目录（如果不存在）
                    avatar_dir = os.path.join(os.path.dirname(self.tdata_path), "avatars")
                    os.makedirs(avatar_dir, exist_ok=True)
            
                    # 基于用户ID固定文件名（避免重复下载）
                    user_id = current_user.id
                    avatar_filename = f"avatar_{user_id}.jpg"
                    avatar_path = os.path.join(avatar_dir, avatar_filename)
            
                    if not os.path.exists(avatar_path):  # 只有不存在时才下载
                        photo_bytes = await client.download_profile_photo(current_user, file=bytes)
                        if photo_bytes:
                            with open(avatar_path, "wb") as f:
                                f.write(photo_bytes)
                            logger.info(f"头像已保存到: {avatar_path}")
                    else:
                        logger.info(f"头像已存在，直接复用: {avatar_path}")
            
            except Exception as e:
                logger.warning(f"保存头像失败: {str(e)}")
                avatar_path = None  # 保存失败时置空

            
            # 获取好友数量
            contacts = await client(GetContactsRequest(hash=0))
            friends_count = len(contacts.users)
            
            # 获取群组数量
            dialogs = []
            async for dialog in client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    dialogs.append(dialog)
            groups_count = len(dialogs)
            
            # 填充返回数据
            result["data"]["username"] = current_user.username
            result["data"]["nickname"] = f"{current_user.first_name} {current_user.last_name or ''}".strip()
            result["data"]["status"] = parse_status(current_user.status)
            result["data"]["friends_count"] = friends_count
            result["data"]["groups_count"] = groups_count
            result["data"]["avatar_url"] = avatar_path  
            
        except Exception as e:
            result["message"] = f"获取账号信息失败: {str(e)}"
            result["data"]["account_status"] = "异常"
            result["data"]["account_status_desc"] = f"获取账号信息失败: {str(e)}"
            
        return result       
    
    # 新增修改功能方法
    """修改账号密码"""
    @handle_account_status
    async def change_password(self, current_password, new_password, client=None, current_user=None, result=None):
        try:
            # 执行密码修改
            await client(UpdatePasswordSettingsRequest(
                current_password=current_password,
                new_password=new_password,
                hint=""  # 可以添加密码提示
            ))
            
            result["status"] = True
            result["message"] = "密码修改成功"
            
        except Exception as e:
            result["message"] = f"密码修改失败: {str(e)}"
            result["data"]["account_status"] = "异常"
            result["data"]["account_status_desc"] = f"密码修改失败: {str(e)}"
            
        return result
    
    """更新头像（传入图片路径）"""
    @handle_account_status
    async def update_profile_photo(self, photo_path, client=None, current_user=None, result=None):
        try:
            # 检查图片文件是否存在
            if not os.path.isfile(photo_path):
                result["message"] = f"图片文件不存在: {photo_path}"
                return result
                
            # 先删除现有头像
            photos = await client.get_profile_photos("me")
            if photos:
                await client(DeletePhotosRequest(
                    id=[InputPhoto(
                        id=photo.id,
                        access_hash=photo.access_hash,
                        file_reference=photo.file_reference
                    ) for photo in photos]
                ))
                
            # 上传新头像
            with open(photo_path, "rb") as f:
                await client(UploadProfilePhotoRequest(
                    file=await client.upload_file(f)
                ))
                
            result["status"] = True
            result["message"] = "头像更新成功"
           
            
        except Exception as e:
            result["message"] = f"头像更新失败: {str(e)}"
            result["data"]["account_status"] = "异常"
            result["data"]["account_status_desc"] = f"头像更新失败: {str(e)}"
            
        return result
    
    """修改昵称（first_name是名，last_name是姓）"""
    async def update_nickname(self, first_name, last_name=""):
        return await self._update_profile(
            first_name=first_name, 
            last_name=last_name
        )
        
    """修改个人签名（bio）"""
    async def update_bio(self, bio):
        return await self._update_profile(about=bio)
        
    """修改用户名（@后的唯一标识）"""
    @handle_account_status
    async def update_username(self, username, client=None, current_user=None, result=None):
        # 执行用户名修改
        try:
            # 如果新旧用户名相同，直接返回
            if current_user and current_user.username == username:
                result["status"] = False
                result["message"] = f"用户名与当前一致，无需修改: {username}"
                result["data"] = {"current_username": current_user.username}
                return result
            # 执行修改
            updated_user = await client(UpdateUsernameRequest(username))
            result["status"] = True
            result["message"] = "用户名修改成功"
        except FloodWaitError as e:
            result["status"] = False
            result["message"] = f"修改过于频繁，请等待 {e.seconds} 秒后再试"
            result["data"] = {"wait_seconds": e.seconds}
        except UsernameOccupiedError:
            result["status"] = False
            result["message"] = f"用户名 '{username}' 已被占用，请换一个"
        except UsernameInvalidError:
            result["status"] = False
            result["message"] = f"用户名 '{username}' 格式无效，请检查规则"
        except Exception as e:
            result["status"] = False
            result["message"] = f"修改失败: {str(e)}"
            
        return result
    """内部通用方法，用于更新个人资料"""    
    @handle_account_status
    async def _update_profile(self, *args, **kwargs):
        client = kwargs.get("client")
        result = kwargs.get("result", {"status": False, "message": ""})
        
        logger.info(f"[clientclient] 有 client: key={client}")
        if not client:
            result["status"] = False
            result["message"] = "未获取到client"
            return result
        # 只保留允许的字段
        allowed_fields = {"first_name", "last_name", "about"}
        profile_kwargs = {k: v for k, v in kwargs.items() if k in allowed_fields}
    
        if not profile_kwargs:
            result = kwargs.get("result", {"status": False, "message": ""})
            result["status"] = False
            result["message"] = "没有有效的资料字段"
            return result
    
        # 执行资料更新
        await client(UpdateProfileRequest(**profile_kwargs))
    
        # 获取更新后的信息
        user = await client.get_me()
        result = kwargs.get("result", {"status": False, "message": ""})
        result["status"] = True
        result["message"] = "资料更新成功"
        result["data"] = {
            "updated_info": {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "about": getattr(user, 'about', "")
            }
        }
        return result
        
    @handle_account_status    
    async def get_history(self, target_id, limit=50, offset=0, client=None, current_user=None,result=None):
        """
        获取指定会话的历史消息
        :param target_id: 目标会话ID（群组/好友/频道）
        :param limit: 消息数量限制
        :param offset: 偏移量（从第N条开始获取）
        :return: 历史消息列表
        """
        result = {"status": False, "message": "", "data": {"messages": [], "total": 0}}
        
        try:
            # 修复1：删除强制转换ID为负数的错误逻辑，保留原始ID
            target_id = int(target_id)
            
            # 修复2：获取会话实体（自动适配用户/群组/频道）
            try:
                entity = await client.get_entity(target_id)
            except ValueError as e:
                # 处理实体不存在的情况
                result["message"] = f"会话不存在或无法访问: {str(e)}"
                return result
            
            # 修复3：优化消息总数计算（使用更高效的方法）
            try:
                # Telethon 支持直接获取消息计数（无需迭代所有消息）
                total_count = await client.get_messages_count(entity)
            except Exception:
                # 兼容不支持的库版本，降级为迭代计数（但限制最大迭代次数避免性能问题）
                total_count = 0
                async for _ in client.iter_messages(entity, limit=10000):  # 限制最大1万条
                    total_count += 1
            result["data"]["total"] = total_count
            
            # 获取历史消息（按时间倒序，offset控制分页）
            messages = []
            async for msg in client.iter_messages(
                entity,
                limit=limit,
                offset_id=offset,
                reverse=False  # 按时间正序排列（旧消息在前）
            ):
                sender_name = None
                if msg.sender:
                    if hasattr(msg.sender, 'first_name') or hasattr(msg.sender, 'last_name'):
                        first = getattr(msg.sender, 'first_name', '') or ''
                        #last = getattr(msg.sender, 'last_name', '') or '' {last}
                        sender_name = f"{first}".strip()
                    elif hasattr(msg.sender, 'title'):
                        # 群组 / 频道
                        sender_name = msg.sender.title
                # 处理回复消息相关信息
                is_reply = False  # 是否为回复消息
                reply_to_msg_id = None  # 被回复的消息ID
                reply_to_text = None  # 被回复的消息内容
                reply_to_sender_id = None
                if msg.reply_to:
                    is_reply = True
                    reply_to_msg_id = msg.reply_to.reply_to_msg_id
                    # 尝试获取被回复的消息内容（最多尝试获取1条）
                    if reply_to_msg_id:
                        try:
                            # 修复后代码
                            replied_msg = await client.get_messages(
                                entity,
                                ids=reply_to_msg_id,
                                limit=1
                            )
                            # 处理单个消息对象或消息列表的情况
                            if replied_msg:
                                # 判断是否为列表（部分版本返回列表，部分返回单个对象）
                                if isinstance(replied_msg, list):
                                    target_msg = replied_msg[0] if replied_msg else None
                                else:
                                    target_msg = replied_msg
                                    reply_to_sender_id = target_msg.sender_id
                                reply_to_text = target_msg.text or "（无文本内容）" if target_msg else "（未找到回复的消息）"
                                
                        except Exception as e:
                            reply_to_text = f"（获取回复内容失败: {str(e)}）"
                            reply_to_sender_id = None  
                            


                # 处理媒体消息（如图片、语音）
                media_type = ""
                media_url = ""
                if msg.media:
                    if hasattr(msg.media, "photo"):
                        media_type = "image"
                        # 下载图片为base64（注意：大图片可能导致性能问题）
                        photo_bytes = await client.download_media(msg.media, file=bytes)
                        import base64
                        media_url = f"data:image/jpeg;base64,{base64.b64encode(photo_bytes).decode()}"
                        
                    elif hasattr(msg.media, "voice"):
                        media_type = "voice"
                        # 语音消息可保存为文件后返回URL，或同样转为base64
                        # voice_bytes = await self.client.download_media(msg.media, file=bytes)
                        # media_url = f"data:audio/ogg;base64,{base64.b64encode(voice_bytes).decode()}"
                
                messages.append({
                    "id": msg.id,
                    "text": msg.text or "",  # 避免None，统一为空字符串
                    "sender_name": sender_name or "Unknown",
                    "date": msg.date.isoformat(),  # 时间格式：ISO 8601
                    "sender_id": msg.sender_id,
                    "media_type": media_type,
                    "media_url": media_url,
                    "is_reply": is_reply,  # 新增：是否为回复消息
                    "reply_to_msg_id": reply_to_msg_id,  # 新增：被回复的消息ID
                    "reply_to_text": reply_to_text,  # 新增：被回复的消息内容
                    "reply_to_sender_id": reply_to_sender_id 
                })
            
            result["status"] = True
            result["message"] = f"成功获取{len(messages)}条历史消息"
            result["data"]["messages"] = messages
            
        except Exception as e:
            result["message"] = f"获取历史消息失败: {str(e)}"
           
                
        return result 
    
    @handle_account_status    
    async def count_total_unread(self, client=None, current_user=None,result=None):
        """统计所有对话中的未读消息总数（补充详细类型）"""
        result = {"status": False, "message": "", "data": {"total_unread": 0, "unread_chats": []}}
        
        try:
            
            total_unread = 0
            unread_chats = []
            
            # 遍历所有对话，补充精确类型
            async for dialog in client.iter_dialogs():
                if dialog.unread_count > 0:
                    # 精确判断会话类型（关键改进）
                    chat_type = "unknown"
                    if dialog.is_user:
                        chat_type = "private"  # 私聊
                    elif dialog.is_group:
                        chat_type = "group"    # 普通群组
                    elif dialog.is_channel:
                        # 区分频道和超级群组（超级群组本质是特殊频道）
                        entity = await client.get_entity(dialog.id)
                        if hasattr(entity, 'megagroup') and entity.megagroup:
                            chat_type = "supergroup"  # 超级群组（归为群组类）
                        else:
                            chat_type = "channel"     # 普通频道
                    
                    total_unread += dialog.unread_count
                    unread_chats.append({
                        "chat_id": dialog.id,
                        "title": dialog.title,
                        "unread_count": dialog.unread_count,
                        "type": chat_type,  # 新增：精确类型
                        "is_group": dialog.is_group or chat_type == "supergroup",  # 超级群组也视为群组
                        "is_private": chat_type == "private"
                    })
            
            #await client.disconnect()
            
            result["status"] = True
            result["message"] = f"未读消息统计完成，共 {total_unread} 条未读消息"
            result["data"]["total_unread"] = total_unread
            result["data"]["unread_chats"] = unread_chats
            
        except Exception as e:
            result["message"] = f"统计未读消息失败: {str(e)}"
            #if self.client and self.client.is_connected():
            #    await self.client.disconnect()
                
        return result
    @handle_account_status
    async def mark_session_as_read(self, session_id, client=None, current_user=None,result=None):
        """
        标记会话中所有消息为已读（使用 send_read_acknowledge）
        """
        result = {"status": False, "message": "", "data": {}}
    
        try:
           
    
            try:
                # 获取 entity（不是 InputPeer）
                entity = await client.get_entity(int(session_id))
    
                # 查找 dialog 获取最新消息 ID
                target_dialog = None
                async for dialog in client.iter_dialogs():
                    if dialog.id == int(session_id):
                        target_dialog = dialog
                        break
    
                if not target_dialog:
                    return {
                        "status": False,
                        "message": f"会话ID不存在或无法访问: {session_id}",
                        "data": {}
                    }
    
                last_message_id = target_dialog.message.id if target_dialog.message else 0
                unread_count = target_dialog.unread_count or 0
    
                if last_message_id > 0:
                    # 核心改动：直接用 send_read_acknowledge
                    await client.send_read_acknowledge(entity, max_id=last_message_id)
    
                    msg = f"会话 {session_id} 已标记为已读，共处理 {unread_count} 条未读消息"
                else:
                    msg = f"会话 {session_id} 无消息可标记"
    
                result.update({
                    "status": True,
                    "message": msg,
                    "data": {
                        "session_id": session_id,
                        "unread_count": unread_count,
                        "last_message_id": last_message_id,
                        #"proxy_used": proxy_info is not None
                    }
                })
    
            except (ValueError, PermissionError, RuntimeError) as e:
                result.update({"status": False, "message": str(e)})
            except Exception as e:
                result.update({"status": False, "message": f"标记失败: {str(e)}"})
    
        except Exception as e:
            result.update({"status": False, "message": f"操作失败: {str(e)}"})
    
        #finally:
            #if self.client and self.client.is_connected():
            #    await self.client.disconnect()
    
        return result
    @handle_account_status
    async def get_common_groups(self, target_id, client=None, current_user=None,result=None):
        """获取与目标用户的共同群组"""
        result = {"status": False, "message": "", "data": {"groups": []}}
        
        try:
            
            # 2. 获取当前账号的所有群组
            my_groups = []
            async for dialog in client.iter_dialogs():
                if dialog.is_group or (dialog.is_channel and hasattr(dialog.entity, 'megagroup') and dialog.entity.megagroup):
                    my_groups.append(dialog.entity.id)

            # 3. 检查目标用户是否在这些群组中
            common_groups = []
            target_id = int(target_id)
            
            for group_id in my_groups:
                try:
                    # 获取群组成员（搜索目标用户）
                    entity = await client.get_entity(group_id)
                    participants = await client(GetParticipantsRequest(
                        channel=entity,
                        filter=ChannelParticipantsSearch(q=""),  # 搜索所有成员
                        offset=0,
                        limit=200,
                        hash=0
                    ))
                    
                    # 检查目标用户是否在成员列表中
                    is_member = any(
                        user.id == target_id 
                        for user in participants.users
                    )
                    
            
                    # 获取头像URL（如果存在）
                    avatar_url = None
                    '''
                    if entity.photo:
                        try:
                            # 下载头像为字节流
                            photo_bytes = await client.download_profile_photo(entity, file=bytes)
                            if photo_bytes:
                                import base64
                                avatar_url = f"data:image/jpeg;base64,{base64.b64encode(photo_bytes).decode()}"
                        except Exception:
                            avatar_url = None
                    '''        
                    if is_member:
                        # 获取群组信息
                        common_groups.append({
                            "id": entity.id,
                            "title": entity.title,
                            "avatar_url": avatar_url,
                            "member_count": entity.participants_count if hasattr(entity, 'participants_count') else 0
                            
                        })
                        
                except (ChannelPrivateError, PeerIdInvalidError):
                    continue  # 跳过无权限的群组
                except Exception as e:
                    print(f"检查群组 {group_id} 失败: {str(e)}")
                    continue

            # 4. 返回结果
            result["status"] = True
            result["data"]["groups"] = common_groups
            result["message"] = f"找到{len(common_groups)}个共同群组"
            #await self.client.disconnect()

        except Exception as e:
            result["message"] = f"获取共同群组失败: {str(e)}"
            #if self.client and self.client.is_connected():
            #    await self.client.disconnect()
        
        return result

    
