import asyncio
import time
from collections import defaultdict
from telethon import TelegramClient
from telethon.tl.functions.account import UpdateStatusRequest
from telethon.errors import RPCError, InputUserDeactivatedError

class TelegramClientPool:
    """Telegram客户端连接池，管理长连接复用"""
    _instance = None  # 单例模式
    
    def __new__(cls):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            # 初始化连接池：{tdata_hash: {"client": ..., "ref_count": 0, "last_used": 0}}
            cls._instance.pool = defaultdict(dict)
            cls._instance.lock = asyncio.Lock()  # 全局锁
            # 启动心跳检测任务
            cls._instance.loop = asyncio.get_event_loop()
            cls._instance.loop.create_task(cls._instance._heartbeat_task())
        return cls._instance

    async def _heartbeat_task(self):
        """定期检测连接活性，关闭长时间闲置的连接"""
        while True:
            await asyncio.sleep(300)  # 每5分钟检测一次
            async with self.lock:
                current_time = time.time()
                for tdata_hash, entry in list(self.pool.items()):
                    # 关闭30分钟未使用且引用计数为0的连接
                    if (current_time - entry["last_used"] > 1800 
                        and entry["ref_count"] == 0):
                        try:
                            if entry["client"].is_connected():
                                await entry["client"].disconnect()
                        except:
                            pass
                        del self.pool[tdata_hash]

    async def get_client(self, tdata_path, api_id, api_hash, proxy_str=None):
        """获取客户端实例（复用已有连接）"""
        tdata_hash = hash(tdata_path)
        async with self.lock:
            # 1. 检查连接池是否已有该客户端
            if tdata_hash in self.pool:
                entry = self.pool[tdata_hash]
                client = entry["client"]
                # 检查连接是否有效
                if client.is_connected():
                    entry["ref_count"] += 1
                    entry["last_used"] = time.time()
                    return client, "复用已有连接"
            
            # 2. 没有有效连接，创建新客户端
            proxy_info = self._parse_proxy(proxy_str) if proxy_str else None
            client = TelegramClient(
                session=tdata_path,
                api_id=api_id,
                api_hash=api_hash,
                proxy=proxy_info,
                connection_retries=3,
                timeout=30
            )
            
            try:
                await client.connect()
                if not await client.is_user_authorized():
                    await client.disconnect()
                    return None, "账号未授权"
                
                # 添加到连接池
                self.pool[tdata_hash] = {
                    "client": client,
                    "ref_count": 1,
                    "last_used": time.time()
                }
                return client, "创建新连接"
            except Exception as e:
                return None, f"连接失败: {str(e)}"

    async def release_client(self, tdata_path):
        """释放客户端引用（减少引用计数）"""
        tdata_hash = hash(tdata_path)
        async with self.lock:
            if tdata_hash in self.pool:
                self.pool[tdata_hash]["ref_count"] -= 1
                self.pool[tdata_hash]["last_used"] = time.time()

    async def disconnect_client(self, tdata_path):
        """主动断开连接并从池移除"""
        tdata_hash = hash(tdata_path)
        async with self.lock:
            if tdata_hash in self.pool:
                entry = self.pool[tdata_hash]
                try:
                    if entry["client"].is_connected():
                        await entry["client"].send(UpdateStatusRequest(offline=True))
                        await entry["client"].disconnect()
                except:
                    pass
                del self.pool[tdata_hash]

    def _parse_proxy(self, proxy_str):
        """解析代理字符串"""
        try:
            proxy_parts = proxy_str.split('://')
            if len(proxy_parts) != 2:
                return None
                
            proxy_type = proxy_parts[0]
            auth_part = proxy_parts[1].split('@')
            if len(auth_part) != 2:
                return None
                
            user_pass, addr_port = auth_part
            user, password = user_pass.split(':') if ':' in user_pass else (user_pass, '')
            addr, port = addr_port.split(':')
            return (proxy_type, addr, int(port), True, user, password)
        except:
            return None
