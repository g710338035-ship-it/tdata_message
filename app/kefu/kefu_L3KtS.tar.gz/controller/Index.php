<?php
namespace app\kefu\controller;
use think\facade\Db;
use think\facade\Log;
use app\kefu\model\Group;
use app\kefu\model\Friend;
use think\facade\Cache;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use app\admin\model\Mtuser as MtuserModel;
class Index extends Baseinfo {
	
	private $httpClient;
    private string $redisPrefix = 'telegram_task:user:';
    public function initialize(){
		parent::initialize();
		$this->httpClient = new Client([
            'timeout'         => 60.0,
            'connect_timeout' => 10.0,
            'read_timeout'    => 30.0,
            'pool'           => 5, // 连接池大小
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'User-Agent'   => 'TelegramApiClient/1.0'
            ]
        ]);
	}
    
	public function main(){
	    
       
        return view('main', ['accountList' => $this->accountList()]);
	}
	public function ws(){
	
       
        return view('ws');
	}
	
	public function index(){
	//	$accounts = $this->accountList()->getData()['data'];
        $kefuinfo = session('kefu');
        $kefuid = $kefuinfo['id'];
        return view('index', ['kefuinfo' => $kefuinfo]);
	}
	
	 // 获取账号列表
    // 修改 accountList() 方法，关联 mtuser 表
    public function accountList()
    {
        $kefuinfo = session('kefu');
        $kefuid = $kefuinfo['id'];
        
        try {
            // 1. 接收前端传递的分页参数（默认值：第1页，每页10条）
            $page = request()->post('page', 1);         // 当前页码（前端传递）
            $pageSize = request()->post('pageSize', 10); // 每页条数（前端传递，可自定义）
            
            // 2. 基础查询条件（保持原逻辑：当前客服的有效账号）
            $query = MtuserModel::where([
                    'customid' => $kefuid,
                    'status' => 1,
                    'archive' => 1,
                    //'account_status'=>'正常'
                ])
                ->field('id, account, online,account_status, tdata_path, session_path, proxyip, nickName,avatar_url');
            
            // 3. 统计符合条件的账号总数（用于前端判断是否还有更多数据）
            $total = $query->count();
            
            // 4. 计算分页偏移量（SQL的 LIMIT 偏移量 = (页码-1)*每页条数）
            $offset = ($page - 1) * $pageSize;
            
            // 5. 执行分页查询（只获取当前页的数据，减少数据库压力和传输量）
            $mtUsers = $query->limit($offset, $pageSize)->select();
           // log::info(json_encode($mtUsers));
            $accounts = [];
            // 6. 处理账号数据（保持原逻辑，补充未读统计等）
            if (!empty($mtUsers)) {
                foreach ($mtUsers as $user) {
                    // TODO: 若需要真实未读数据，可恢复Python脚本调用（此处保留原注释逻辑）
                    /*$result = $this->execPythonScript([
                        'action' => 'count_total_unread',  
                        'tdata_path' => $user['session_path'],
                        'proxyip' => $user['proxyip']
                    ]);
                    log::info(json_encode($result));*/
                    
                    // 组装账号数据（未读数据暂时用固定值，实际项目需替换为Python返回的真实值）
                    $accounts[] = [
                        'tpid' => $user['id'],
                        'account' => $user['account'] ?? '',
                        'nickName' => $user['nickName'] ?? '',
                        'avatar_url' => $user['avatar_url'] ?? '',
                        'account_status' => $user['account_status'] ?? '',
                        'unread' => 1, // 临时固定值，需替换为真实未读统计
                        'online' => $user['online'] == 1 ? true : false,
                        'unread_chats' => 0 // 临时固定值，按需补充
                    ];
                }
            }
            
            // 7. 返回分页格式数据（前端需要 total、page、pageSize 来判断分页状态）
            return json([
                'code' => 200,
                'msg' => 'success',
                'data' => [
                    'list' => $accounts,       // 当前页的账号列表
                    'total' => $total,         // 账号总数
                    'page' => $page,           // 当前页码（回传前端，保持一致性）
                    'pageSize' => $pageSize    // 每页条数（回传前端，保持一致性）
                ]
            ]);
        } catch (\Exception $e) {
            Log::error('获取账号列表失败: ' . $e->getMessage());
            return json([
                'code' => 500, 
                'msg' => '获取账号列表失败：' . $e->getMessage()
            ]);
        }
    }
    public function getaccount()
    {
        $chat_id = $this->request->post('chat_id');
        $is_group = $this->request->post('is_group');
        
        $kefuinfo = session('kefu');
        $kefuid = $kefuinfo['id'];
        try {
           
            $accounts = [];
            if($is_group===true){
                $mtUsers = Group::where(['group_id'=>$chat_id])->field('id, tdata_id')->select();
            }else{
            // 从数据库获取所有客服的 tdata 配置where('customid',$kefuid)->
                $mtUsers = Friend::where(['user_id'=>$chat_id])->field('id, tdata_id')->select();
            }
            
            $mtUserMap = [];
            // 判断是否有账号数据
            if (empty($mtUsers)) {
                return json([
                    'code' => 200,
                    'msg' => '暂无可用账号',
                    'data' => $accounts // 返回空数组
                ]);
            }

            
            return json([
                'code' => 200,
                'msg' => 'success',
                'data' => $mtUsers['tdata_id']
            ]);
        } catch (\Exception $e) {
            Log::error('获取账号列表失败: ' . $e->getMessage());
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    // 加载会话列表（群组+好友）
    public function loadSessions()
    {
        $tdataid = $this->request->post('tpid');
        $kefuinfo = session('kefu');
        $kefuid = $kefuinfo['id'];
        
        // 增加缓存检查
        $cacheKey = "sessions_{$tdataid}_{$kefuid}";
        $cachedData = cache($cacheKey);
        if ($cachedData && !$this->request->post('force_refresh', false)) {
            return json([
                'code' => 200,
                'msg' => '从缓存加载成功',
                'data' => $cachedData
            ]);
        }
        
        $mtUsers =Cache::store('redis')->get($this->redisPrefix . $tdataid);
        if (!$mtUsers) {
            $mtUsers = Db::name('mtuser')->where('id',$tdataid)->field('id, tdata_path,session_path, account,proxyip, nickName,last_api_address')->find();
            if (!$mtUsers) {
                return json(['code' => 400, 'msg' => '账号不存在']);
            }
            Cache::store('redis')->set($this->redisPrefix . $tdataid, $mtUsers, 60);
        }
        
        
        if(empty($mtUsers['proxyip'])||empty($mtUsers['session_path'])|| !file_exists($mtUsers['session_path'])){
    		//throw new ValidateException('缺少tdata路径信息，无法操作Telegram账号');
    		return json(['code'=>400,'msg'=>'缺少tdata路径信息，无法操作Telegram账号,'.$mtUsers['account_status_desc']]);
    	}
        try {
            $startTime = microtime(true);
            // 并行执行Python脚本（如果支持）
            $groupsResult = $this->execPythonScript([
                'action' => 'get_groups',
                'session_path' => $mtUsers['session_path'],
                'proxyip' => $mtUsers['proxyip'],
                'apiaddress' => $mtUsers['last_api_address']
            ]);
            $groupsTime = round((microtime(true) - $startTime) * 1000, 2); // 毫秒级耗时
            Log::info("【Python调用】get_groups 执行耗时：{$groupsTime} ms");
          
            $startTime = microtime(true);
            $friendsResult = $this->execPythonScript([
                'action' => 'get_contacts',
                'session_path' => $mtUsers['session_path'],
                'proxyip' => $mtUsers['proxyip'],
                'apiaddress' => $mtUsers['last_api_address']
            ]);
            $friendsTime = round((microtime(true) - $startTime) * 1000, 2);
            Log::info("【Python调用】get_contacts 执行耗时：{$friendsTime} ms");
            // 处理群组数据 - 使用批量操作
           if ($groupsResult['status']) {
                $groups = $groupsResult['data']['groups'];
                $newGroupIds = array_column($groups, 'id');
                
                // 批量获取现有记录
                $existingGroups = Group::where('tdata_id', $tdataid)
                    ->whereIn('group_id', $newGroupIds)
                    ->select()
                    ->toArray();
                
                $existingGroups = array_column($existingGroups, null, 'group_id');
                
                $createData = [];
                $updateData = [];
                
                foreach ($groups as $group) {
                    $groupId = $group['id'];
                    $groupData = [
                        'title' => $group['title'],
                        'type' => $group['type'],
                        'avatar' => $group['avatar_web_path'] ?? '',
                        'unread_count' => $group['unread_count'] ?? 0,
                        'last_msg' => $group['last_msg'] ?? '',
                        'member_count' => $group['member_count'] ?? 0,
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    
                    if (isset($existingGroups[$groupId])) {
                        // 只更新有变化的字段
                        $existing = $existingGroups[$groupId];
                        $changes = [];
                        foreach ($groupData as $key => $value) {
                            if ($existing->$key != $value) {
                                $changes[$key] = $value;
                            }
                        }
                        if (!empty($changes)) {
                            $changes['id'] = $existing->id;
                            $updateData[] = $changes;
                        }
                    } else {
                        $groupData['tdata_id'] = $tdataid;
                        $groupData['group_id'] = $groupId;
                        $groupData['created_at'] = date('Y-m-d H:i:s');
                        $groupData['customid'] = $kefuid;
                        $createData[] = $groupData;
                    }
                }
                
                // 批量操作
                if (!empty($createData)) {
                    Group::insertAll($createData);
                }
                if (!empty($updateData)) {
                    foreach ($updateData as $data) {
                        $id = $data['id'];
                        unset($data['id']);
                        Group::where('id', $id)->update($data);
                    }
                }
                
                // 删除不在新列表中的群组
                if (!empty($newGroupIds)) {
                    Group::where('tdata_id', $tdataid)
                        ->whereNotIn('group_id', $newGroupIds)
                        ->delete();
                } else {
                    Group::where('tdata_id', $tdataid)->delete();
                }
            }
            
            // 处理好友数据 - 类似群组的批量操作优化
             if ($friendsResult['status']) {
                $friends = $friendsResult['data']['private_chats'];
                $newFriendIds = array_column($friends, 'id');
                
                $existingFriends = Friend::where('tdata_id', $tdataid)
                    ->whereIn('user_id', $newFriendIds)
                    ->select()
                    ->toArray();
                
                $existingFriends = array_column($existingFriends, null, 'user_id');
                
                $createFriends = [];
                $updateFriends = [];
                
                foreach ($friends as $friend) {
                    $friendId = $friend['id'];
                    $friendData = [
                        'username' => $friend['username'] ?? '',
                        'first_name' => $friend['first_name'] ?? '',
                        'last_name' => $friend['last_name'] ?? '',
                        'avatar' => $friend['avatar_url'] ?? '',
                        'unread_count' => $friend['unread_count'] ?? 0,
                        'last_msg' => $friend['last_msg'] ?? '',
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    
                    if (isset($existingFriends[$friendId])) {
                        $existing = $existingFriends[$friendId];
                        $changes = [];
                        foreach ($friendData as $key => $value) {
                            if ($existing->$key != $value) {
                                $changes[$key] = $value;
                            }
                        }
                        if (!empty($changes)) {
                            $changes['id'] = $existing->id;
                            $updateFriends[] = $changes;
                        }
                    } else {
                        $friendData['tdata_id'] = $tdataid;
                        $friendData['user_id'] = $friendId;
                        $friendData['created_at'] = date('Y-m-d H:i:s');
                        $friendData['customid'] = $kefuid;
                        $createFriends[] = $friendData;
                    }
                }
                
                if (!empty($createFriends)) {
                    Friend::insertAll($createFriends);
                }
                if (!empty($updateFriends)) {
                    foreach ($updateFriends as $data) {
                        $id = $data['id'];
                        unset($data['id']);
                        Friend::where('id', $id)->update($data);
                    }
                }
                
                if (!empty($newFriendIds)) {
                    Friend::where('tdata_id', $tdataid)
                        ->whereNotIn('user_id', $newFriendIds)
                        ->delete();
                } else {
                    Friend::where('tdata_id', $tdataid)->delete();
                }
            }
           
            // 获取结果并缓存
            $groups = Group::where('tdata_id', $tdataid)->select();
            $friends = Friend::where('tdata_id', $tdataid)->select();
            
            $resultData = [
                'groups' => $groups,
                'friends' => $friends
            ];
            
            // 缓存结果（1分钟）
            cache($cacheKey, $resultData, 60);
            
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => $resultData,
                'groupsResult'=>$groupsResult
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }

    public function loadSessionsnew()
    {
        $tdataid = $this->request->post('tpid');
        $kefuinfo = session('kefu');
        $kefuid = $kefuinfo['id'];
        
        $mtUsers = Db::name('mtuser')->where('id', $tdataid)->where('customid', $kefuid)->field('id, tdata_path,session_path, customid, account, proxyip, nickName,last_api_address')->find();
        
        try {
            // 获取群组列表（包含头像、未读、最后消息）
            $groupsResult = $this->execPythonScript([
                'action' => 'get_groups',
                'tdata_path' => $mtUsers['session_path'],
                'proxyip' => $mtUsers['proxyip'],
                'apiaddress' => $mtUsers['last_api_address'],
            ]);
            
            $groups = [];
            if ($groupsResult['status']) {
                $groups = $groupsResult['data']['groups'] ?? [];
                // 可以在这里对群组数据进行必要的格式化处理
                foreach ($groups as &$group) {
                    // 示例：统一字段名或补充默认值
                    $group['avatar'] = $group['avatar_url'] ?? '';
                    $group['unread_count'] = $group['unread_count'] ?? 0;
                    $group['last_msg'] = $group['last_msg'] ?? '';
                    $group['member_count'] = $group['member_count'] ?? 0;
                    unset($group['avatar_url']); // 移除冗余字段（如果需要）
                }
            }
            
            // 获取好友列表
            $friendsResult = $this->execPythonScript([
                'action' => 'get_contacts',
                'tdata_path' => $mtUsers['session_path'],
                'proxyip' => $mtUsers['proxyip'],
                'apiaddress' => $mtUsers['last_api_address'],
            ]);
            
            $friends = [];
            if ($friendsResult['status']) {
                $friends = $friendsResult['data']['private_chats'] ?? [];
                // 对好友数据进行必要的格式化处理
                foreach ($friends as &$friend) {
                    $friend['avatar'] = $friend['avatar_url'] ?? '';
                    $friend['unread_count'] = $friend['unread_count'] ?? 0;
                    $friend['last_msg'] = $friend['last_msg'] ?? '';
                    unset($friend['avatar_url']); // 移除冗余字段（如果需要）
                }
            }
            
            // 直接返回原始数据（已做简单格式化）
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'groups' => $groups,
                    'friends' => $friends
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    // 发送消息
    public function sendMessage()
    {
        $params = $this->request->post();
        $required = ['tpid', 'target_id', 'message_type'];
        
        foreach($required as $field) {
            if(empty($params[$field])) {
                return json(['code' => 400, 'msg' => "缺少参数: {$field}"]);
            }
        }
        
        $images = [];
    if (in_array($params['message_type'], ['image', 'image_text'])) {
        // 校验前端是否传递了images参数（兼容JSON字符串/数组格式）
        $imagesRaw = $params['images'] ?? '';
        if (empty($imagesRaw)) {
            return json(['code' => 400, 'msg' => $params['message_type'] . '类型消息需传递图片列表']);
        }
        
        // 解析图片参数（前端可能传JSON字符串或数组）
        if (is_string($imagesRaw)) {
            $images = json_decode($imagesRaw, true);
            // 校验JSON解析是否成功
            if (json_last_error() !== JSON_ERROR_NONE) {
                return json(['code' => 400, 'msg' => '图片参数格式错误（需JSON格式）']);
            }
        } else {
            $images = $imagesRaw;
        }
        
        // 过滤无效图片（确保每张图都有完整URL）
        $validImages = [];
        $baseCdnUrl = rtrim(config('telegram.cdn_domain'), '/'); // 从配置获取CDN域名（如https://cdn.xxx.com）
        foreach ($images as $img) {
            // 跳过空值或格式错误的图片
            if (empty($img['file_url'])) continue;
            
            // 处理图片URL：若为相对路径，拼接CDN域名；若为完整URL，直接使用
            $imgUrl = $img['file_url'];
            if (!str_starts_with($imgUrl, 'http://') && !str_starts_with($imgUrl, 'https://')) {
                $imgUrl = $baseCdnUrl . '/' . ltrim($imgUrl, '/'); // 避免拼接出//的情况
            }
            
            $validImages[] = $imgUrl;
        }
        
        // 校验有效图片数量（至少1张）
        if (empty($validImages)) {
            return json(['code' => 400, 'msg' => '无有效图片URL，请检查图片参数']);
        }
    }
        
        
        $tdataid = $this->request->post('tpid');
        
        $kefuinfo = session('kefu');
        $kefuid =  $kefuinfo['id'];
        $first_msg_id = 0;
        $feedback_type='';
        if (isset($params['reply_to_msg_id']) && 
            $params['reply_to_msg_id'] !== '' && 
            $params['reply_to_msg_id'] !== null &&
            is_numeric($params['reply_to_msg_id'])) {
            $first_msg_id = (int)$params['reply_to_msg_id'];
            $feedback_type='forward';
        }
        $mtUsers =Cache::store('redis')->get($this->redisPrefix . $tdataid);
        if (!$mtUsers) {
            $mtUsers = Db::name('mtuser')->where('id',$tdataid)->field('id, tdata_path,session_path, account,proxyip, nickName,last_api_address')->find();
            if (!$mtUsers) {
                return json(['code' => 400, 'msg' => '账号不存在']);
            }
            Cache::store('redis')->set($this->redisPrefix . $tdataid, $mtUsers, 60);
        }
        
        try {
            $scriptParams = [
                'action' => 'send_messages',
                'session_path' => $mtUsers['session_path'],
                'group_id' => $params['target_id'],
                'message_type' => $params['message_type'],
                'message_text' => $params['message_text'],
                'proxyip'=>$mtUsers['proxyip'],
                'first_msg_id' =>$first_msg_id,
                'feedback_type'=>$feedback_type,
                'apiaddress'=>$mtUsers['last_api_address'],
            ];
            if (!empty($validImages)) {
                $scriptParams['media_paths'] = implode(',', $validImages); // 图片URL列表（Python端按逗号分割）
            }
            $result = $this->execPythonScript($scriptParams);
            
            return json([
                'code' => $result['status'] ? 200 : 400,
                'msg' => $result['message']
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    
 
    /**
     * 加载历史消息
     * @return \think\response\Json
     */
    public function loadHistory()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid'); // 关联的tdata标识
        $targetId = $this->request->post('target_id'); // 目标会话ID（群组/好友）
        $limit = $this->request->post('limit', 10); // 每页消息数，默认50
        $offset = $this->request->post('offset', 0); // 偏移量，用于分页
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id,tdata_path,session_path, proxyip,uuid,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60);
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'get_history', // 对应Python脚本中的动作
                'session_path' => $mtUser['session_path'],
                'proxyip' => $mtUser['proxyip'],
                'target_id' => $targetId,
                'limit' => $limit,
                'offset' => $offset,
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];
            $formattedMessages = [];
    
            foreach ($messages as $msg) {
                // 区分发送者是否为当前账号（需提前获取当前账号user_id）
                $currentUserId = $mtUser['uuid']; // 自定义方法获取当前账号ID
                $isOutgoing = $msg['sender_id'] == $currentUserId;
    
                // 格式化消息时间
                $msgTime = date('Y-m-d H:i:s', strtotime($msg['date']));
    
                $formattedMessages[] = [
                    'id' => $msg['id'], // 消息ID
                    'text' => $msg['text'] ?? '[无文本内容]', // 消息内容
                    'date' => $msgTime, // 发送时间
                    'sender_id' => $msg['sender_id'], // 发送者ID
                    'sender_name'=>$msg['sender_name'],
                    'is_outgoing' => $isOutgoing, // 是否为当前账号发送
                    'media_type' => $msg['media_type'] ?? '', // 媒体类型（如image/voice）
                    'media_url' => $msg['media_url'] ?? '', // 媒体URL（如有）
                    "is_reply"=> $msg['is_reply'] ?? '',  # 新增：是否为回复消息
                    "reply_to_msg_id"=> $msg['reply_to_msg_id'] ?? '',  # 新增：被回复的消息ID
                    "reply_to_text"=> $msg['reply_to_text'] ?? '',  # 新增：被回复的消息内容
                    'reply_to_sender_id'=>$msg['reply_to_sender_id']?? ''
                ];
            }
    
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $formattedMessages,
                    'has_more' => count($messages) >= $limit, // 是否还有更多消息
                    'total' => $historyResult['data']['total'] ?? count($formattedMessages) // 总消息数
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
    
    public function getCommonGroups()
    {
        try {
            $tdataId = $this->request->post('tpid');
            $targetUserId = $this->request->post('target_user_id');
            
            if (empty($tdataId) || empty($targetUserId)) {
                return json(['code' => 400, 'msg' => '缺少参数']);
            }
            
            // 1. 获取当前账号信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id, tdata_path,session_path,proxyip,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '账号不存在']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60);
            }
            log::info($mtUser['last_api_address']);
            // 2. 调用Python脚本获取共同群组
            $result = $this->execPythonScript([
                'action' => 'get_common_groups',
                'session_path' => $mtUser['session_path'],
                'target_id' => $targetUserId,
                'proxyip' => $mtUser['proxyip'] ?? '',
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
            
            if ($result['status'] ?? false) {
                return json([
                    'code' => 200,
                    'data' => ['groups' => $result['data']['groups'] ?? []]
                ]);
            } else {
                return json([
                    'code' => 500,
                    'msg' => $result['message'] ?? '获取共同群组失败'
                ]);
            }
        } catch (\Exception $e) {
            Log::error('获取共同群组异常: ' . $e->getMessage());
            return json(['code' => 500, 'msg' => '服务器错误']);
        }
    }
    
    
    /**
     * 加载历史消息
     * @return \think\response\Json
     */
    public function readmsg()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid'); // 关联的tdata标识
        $targetId = $this->request->post('target_id'); // 目标会话ID（群组/好友）
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id,tdata_path,session_path, proxyip , uuid,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60);
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'mark_session_as_read', // 对应Python脚本中的动作
                'session_path' => $mtUser['session_path'],
                'proxyip' => $mtUser['proxyip'],
                'group_id' => $targetId,
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];

    
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $messages,
                    'data' => $historyResult['data']['data'],
                   
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
    
    
    /**
     * 拉黑用户
     * @return \think\response\Json
     */
    public function blockUser()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid'); // 关联的tdata标识
        $targetId = $this->request->post('user_id'); // 目标会话ID（群组/好友）
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id,tdata_path,session_path, proxyip,uuid,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60);
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'block_user', // 对应Python脚本中的动作
                'session_path' => $mtUser['session_path'],
                'proxyip' => $mtUser['proxyip'],
                'target_id' => $targetId,
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];
            Friend::where('tdata_id', $tdataId)
                          ->where('user_id', $targetId)
                          ->delete();
    
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $messages,
                    'data' => $historyResult['data']['data'],
                   
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
    public function deleteUser()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid'); // 关联的tdata标识
        $targetId = $this->request->post('user_id'); // 目标会话ID（群组/好友）
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id,tdata_path,session_path, proxyip,uuid,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60); 
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'deleteUser', // 对应Python脚本中的动作
                'session_path' => $mtUser['session_path'],  
                'proxyip' => $mtUser['proxyip'],
                'target_id' => $targetId,
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];
            
            Friend::where('tdata_id', $tdataId)
                          ->where('user_id', $targetId)
                          ->delete();
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $messages,
                    'data' => $historyResult['data']['data'],
                   
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
    /**
     * 删除聊天记录
     * @return \think\response\Json
     */
    public function deleteHistory()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid'); // 关联的tdata标识
        $targetId = $this->request->post('target_id'); // 目标会话ID（群组/好友）
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id,tdata_path,session_path, proxyip,uuid,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60); 
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'delete_chat_history', // 对应Python脚本中的动作
                'session_path' => $mtUser['session_path'],
                'proxyip' => $mtUser['proxyip'],
                'target_id' => $targetId,
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];

    
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $messages,
                    'data' => $historyResult['data']['data'],
                   
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
 
    
    public function checkNewMessages()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tpid');
        
        // 参数验证
        if (empty($tdataId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path（账号标识）']);
        }
        
        try {
            // 1. 获取账号的基础信息（tdata路径、代理等）
            $mtUser =Cache::store('redis')->get($this->redisPrefix . $tdataId);
            if (!$mtUser) {
                $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id, tdata_path,session_path, proxyip,last_api_address')
                ->find();
                if (!$mtUser) {
                    return json(['code' => 404, 'msg' => '未找到对应的账号信息']);
                }
                Cache::store('redis')->set($this->redisPrefix . $tdataId, $mtUser, 60); 
            }
            
            // 2. 调用Python脚本获取全账号未读统计
            $result = $this->execPythonScript([
                'action' => 'count_total_unread',  // 对应Python脚本的动作标识
                'session_path' => $mtUser['session_path'],
                'proxyip' => $mtUser['proxyip'],
                'apiaddress'=>$mtUser['last_api_address'],
            ]);
            
            // 3. 处理脚本返回结果
            if (!$result['status']) {
                // 脚本执行失败（如TDATA异常、网络问题）
                Log::warning("统计未读消息失败：{$result['message']}", [
                    'tdata_id' => $tdataId,
                    'tdata_path' => $mtUser['session_path']
                ]);
                return json([
                    'code' => 200,  // 非致命错误，返回0未读避免前端异常
                    'data' => ['unread' => 0]
                ]);
            }
            
            // 4. 格式化并返回结果
            return json([
                'code' => 200,
                'data' => [
                    'unread' => intval($result['data']['total_unread'] ?? 0),
                    'timestamp' => time()  // 便于前端判断统计时间
                ]
            ]);
            
        } catch (\Exception $e) {
            // 捕获异常并记录日志
            Log::error("checkNewMessages接口异常：{$e->getMessage()}", [
                'tdata_id' => $tdataId,
                'trace' => $e->getTraceAsString()
            ]);
            return json([
                'code' => 500,
                'msg' => '检查未读消息失败：' . $e->getMessage()
            ]);
        }
    }
    
    
    // 执行Python脚本
	private function execPythonScript($params)
    {
       /* $this->httpClient = $httpClient ?? new Client([
            'timeout'         => 60.0,      // 整体超时时间
            'connect_timeout' => 10.0,      // 连接超时时间
            'read_timeout'    => 30.0,      // 读取超时时间
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'User-Agent'   => 'TelegramApiClient/1.0'
            ]
        ]);*/
        // Flask 服务的基础 URL
        $baseUrl = $params['apiaddress']; // 替换为你的 Flask 服务地址
        $url = $baseUrl . '/telegram_action';
        $action=$params['action'];
        $proxy=$params['proxyip'];
        $sessionPath=$params['session_path'];
        // 基础请求数据
        $requestData = [
            'action'    => $action,
            'api_id'    => config('telegram.api_id'),
            'api_hash'  => config('telegram.api_hash')
        ];

        // 添加tdata路径
        if ($sessionPath) {
            $requestData['tdata_path'] = $sessionPath;
        }

        // 处理代理信息
        if ($proxy) {
            $proxyParts = explode('##', $proxy);
            if (count($proxyParts) >= 3) {
                list($ipPort, $username, $password) = $proxyParts;
                $requestData['proxy'] = "socks5://{$username}:{$password}@{$ipPort}";
            } else {
                $error = "代理格式错误，正确格式应为: ip:port##username##password";
                log::error($error, ['proxy' => $proxy]);
                throw new \Exception($error);
            }
        }
        foreach($params as $key => $value) {
            if($key != 'action'&&$key != 'proxyip'&&$key != 'tdata_path') {
                $requestData[$key]=$value;
            }
        }
        log::info(json_encode($requestData,JSON_UNESCAPED_UNICODE));
        // 合并额外参数
        try {
            
            // 发送POST请求
            $response = $this->httpClient->post($url, [
                'json' => $requestData
            ]);

            // 获取响应内容
            $responseBody = $response->getBody()->getContents();
            log::debug('接口响应原始数据', [
                'action' => $action,
                'body'   => $responseBody
            ]);

            // 解析JSON响应
            $result = json_decode($responseBody, true);

            // 检查JSON解析错误
            if (json_last_error() !== JSON_ERROR_NONE) {
                $error = "JSON解析失败: " . json_last_error_msg();
                throw new \Exception($error);
            }

            // 检查接口返回状态
            if (empty($result['status'])) {
                $message = $result['message'] ?? '接口返回未知错误';
                
                throw new \Exception("操作失败: {$message}");
            }

            log::info('接口调用成功action'. $action.',result'. json_encode($result,JSON_UNESCAPED_UNICODE));

            return $result;

        } catch (RequestException $e) {
            // 处理HTTP请求异常
            $errorDetails = [];
            $errorMessage = "请求接口失败: ";

            if ($e->hasResponse()) {
                $statusCode = $e->getResponse()->getStatusCode();
                $errorBody = $e->getResponse()->getBody()->getContents();
                $errorMessage .= "状态码: {$statusCode}, 错误内容: {$errorBody}";
                $errorDetails['status_code'] = $statusCode;
                $errorDetails['response_body'] = $errorBody;
            } else {
                $errorMessage .= $e->getMessage();
            }

            $errorDetails['action'] = $action;
            $errorDetails['exception'] = $e->getMessage();
            $errorDetails['trace'] = $e->getTraceAsString();
            
            log::error($errorMessage, $errorDetails);
            throw new \Exception($errorMessage);

        }  catch (\Exception $e) {
            // 处理其他异常
            log::error('接口调用发生异常', [
                'action'  => $action,
                'message' => $e->getMessage(),
                'trace'   => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }
	
}