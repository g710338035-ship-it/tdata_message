<?php
namespace app\kefu\model;

use think\Model;

class Friend extends Model
{
    protected $pk = 'id';
    protected $table = 'cd_kefu_friends';
    protected $autoWriteTimestamp = true;
    
    protected $schema = [
        'id' => 'int',
        'tdata_id' => 'string', // tdata标识
        'user_id' => 'bigint',  // 用户ID
        'username' => 'string', // 用户名
        'first_name' => 'string',
        'last_name' => 'string',
        'updated_at' => 'datetime'
    ];
}