<?php
namespace app\kefu\model;

use think\Model;

class Group extends Model
{
    protected $pk = 'id';
    protected $table = 'cd_kefu_groups';
    protected $autoWriteTimestamp = true;
    
    protected $schema = [
        'id' => 'int',
        'tdata_id' => 'string', // tdata标识
        'group_id' => 'bigint', // 群组ID
        'title' => 'string',    // 群组名称
        'type' => 'string',     // 类型：group/channel
        'updated_at' => 'datetime'
    ];
}