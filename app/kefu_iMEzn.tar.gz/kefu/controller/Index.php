<?php
namespace app\kefu\controller;
use think\facade\Db;
use think\facade\Log;
use app\kefu\model\Group;
use app\kefu\model\Friend;
class Index extends Baseinfo {
	
	
	public function index(){
		$accounts = $this->accountList()->getData()['data'];
       
        return view('index', ['accounts' => $accounts]);
	}
	
	 // 获取账号列表
    // 修改 accountList() 方法，关联 mtuser 表
    public function accountList()
    {
        $kefuinfo = session('kefu');
        $kefuid = session('admin_sign') == data_auth_sign($kefuinfo) ? $kefuinfo['id'] : 0;
        try {
           
            $accounts = [];
            
            // 从数据库获取所有客服的 tdata 配置
            $mtUsers = Db::name('mtuser')->where('customid',$kefuid)->field('id,  account, nickName')->select();
            $mtUserMap = [];
            
            foreach ($mtUsers as $user) {
         
                $accounts[] = [
                         
                                'mtuser_id' => $user['id'],
                                'account' => $user['account'] ?? '', // 客服账号
                                'nickName' => $user['nickName'] ?? '' // 客服昵称
                            ];
            }
            
          
            
            return json([
                'code' => 200,
                'msg' => 'success',
                'data' => $accounts
            ]);
        } catch (Exception $e) {
            Log::error('获取账号列表失败: ' . $e->getMessage());
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    
    // 加载会话列表（群组+好友）
    public function loadSessions()
    {
        $tdataid = $this->request->post('tdata_path');
        $kefuinfo = session('kefu');
        $kefuid = session('admin_sign') == data_auth_sign($kefuinfo) ? $kefuinfo['id'] : 0;
        
        $mtUsers = Db::name('mtuser')->where('id', $tdataid)->where('customid',$kefuid)->field('id, tdata_path,customid, account, proxyip, nickName')->find();
        
        try {
            // 获取群组列表（包含头像、未读、最后消息）
            $groupsResult = $this->execPythonScript([
                'action' => 'get_groups',
                'tdata_path' => $mtUsers['tdata_path'],
                'proxyip' => $mtUsers['proxyip']
            ]);
            
            // 处理群组信息（增量更新）
            if ($groupsResult['status']) {
                $newGroupIds = [];
                $groups = $groupsResult['data']['groups'];
                
                foreach ($groups as $group) {
                    $newGroupIds[] = $group['id'];
                    
                    // 检查记录是否存在
                    $existing = Group::where('tdata_id', $tdataid)
                                    ->where('group_id', $group['id'])
                                    ->find();
                    
                    $groupData = [
                        'title' => $group['title'],
                        'type' => $group['type'],
                        'avatar' => $group['avatar_url'] ?? '',  // 保存头像URL
                        'unread_count' => $group['unread_count'] ?? 0,  // 保存未读数量
                        'last_msg' => $group['last_msg'] ?? '',  // 保存最后一条消息
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    
                    if ($existing) {
                        // 更新已有记录
                        $existing->save($groupData);
                    } else {
                        // 新增记录（补充创建时间）
                        $groupData['tdata_id'] = $tdataid;
                        $groupData['group_id'] = $group['id'];
                        $groupData['created_at'] = date('Y-m-d H:i:s');
                        $groupData['customid'] = $kefuid;
                        Group::create($groupData);
                    }
                }
                
                // 删除不在新列表中的群组
                if (!empty($newGroupIds)) {
                    Group::where('tdata_id', $tdataid)
                         ->whereNotIn('group_id', $newGroupIds)
                         ->delete();
                } else {
                    Group::where('tdata_id', $tdataid)->delete();
                }
            }
            
            // 获取好友列表（假设返回结构包含头像、未读、最后消息）
            $friendsResult = $this->execPythonScript([
                'action' => 'get_contacts',
                'tdata_path' => $mtUsers['tdata_path'],
                'proxyip' => $mtUsers['proxyip']  // 补充代理参数（如果需要）
            ]);
            
            // 处理好友信息（增量更新）
            if ($friendsResult['status']) {
                $newFriendIds = [];
                $friends = $friendsResult['data']['contacts'];
                
                foreach ($friends as $friend) {
                    $newFriendIds[] = $friend['id'];
                    
                    // 检查记录是否存在
                    $existing = Friend::where('tdata_id', $tdataid)
                                     ->where('user_id', $friend['id'])
                                     ->find();
                    
                    $friendData = [
                        'username' => $friend['username'] ?? '',
                        'first_name' => $friend['first_name'] ?? '',
                        'last_name' => $friend['last_name'] ?? '',
                        'avatar' => $friend['avatar_url'] ?? '',  // 保存头像URL
                        'unread_count' => $friend['unread_count'] ?? 0,  // 保存未读数量
                        'last_msg' => $friend['last_msg'] ?? '',  // 保存最后一条消息
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    
                    if ($existing) {
                        // 更新已有记录
                        $existing->save($friendData);
                    } else {
                        // 新增记录（补充创建时间）
                        $friendData['tdata_id'] = $tdataid;
                        $friendData['user_id'] = $friend['id'];
                        $friendData['created_at'] = date('Y-m-d H:i:s');
                        $groupData['customid'] = $kefuid;
                        Friend::create($friendData);
                    }
                }
                
                // 删除不在新列表中的好友
                if (!empty($newFriendIds)) {
                    Friend::where('tdata_id', $tdataid)
                          ->whereNotIn('user_id', $newFriendIds)
                          ->delete();
                } else {
                    Friend::where('tdata_id', $tdataid)->delete();
                }
            }
            
            // 返回包含新字段的列表
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'groups' => Group::where('tdata_id', $tdataid)->select(),
                    'friends' => Friend::where('tdata_id', $tdataid)->select()
                ]
            ]);
        } catch (Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    
    // 发送消息
    public function sendMessage()
    {
        $params = $this->request->post();
        $required = ['tdata_path', 'target_id', 'message_type', 'message_text'];
        
        foreach($required as $field) {
            if(empty($params[$field])) {
                return json(['code' => 400, 'msg' => "缺少参数: {$field}"]);
            }
        }
        $tdataid = $this->request->post('tdata_path');
        
        $kefuinfo = session('kefu');
        $kefuid = session('admin_sign') == data_auth_sign($kefuinfo) ? $kefuinfo['id'] : 0;
        
        $mtUsers = Db::name('mtuser')->where('id',$tdataid)->where('customid',$kefuid)->field('id, tdata_path, account,proxyip, nickName')->find();
        try {
            $scriptParams = [
                'action' => 'send_messages',
                'tdata_path' => $mtUsers['tdata_path'],
                'group_id' => $params['target_id'],
                'message_type' => $params['message_type'],
                'message_text' => $params['message_text'],
                'proxyip'=>$mtUsers['proxyip']
            ];
            
            $result = $this->execPythonScript($scriptParams);
            
            return json([
                'code' => $result['status'] ? 200 : 400,
                'msg' => $result['message']
            ]);
        } catch (Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    
    // 长轮询获取新消息
    public function pollMessages()
    {
        $tdataid = $this->request->post('tdata_path');
        $mtUsers = Db::name('mtuser')->where('id',$tdataid)->field('id, tdata_path, account,proxyip, nickName')->find();
        
        
        $tdataPath = $mtUsers['tdata_path'];
        $lastMsgId = $this->request->post('last_msg_id', 0);
        $targetId = $this->request->post('target_id');
        
        try {
            $result = $this->execPythonScript([
                'action' => 'get_new_messages',
                'tdata_path' => $tdataPath,
                'target_id' => $targetId,
                'last_msg_id' => $lastMsgId,
                'timeout' => 3,
                'proxyip'=>$mtUsers['proxyip']
            ]);
            
            return json([
                'code' => 200,
                'data' => $result['data'] ?? []
            ]);
        } catch (Exception $e) {
            return json(['code' => 500, 'msg' => $e->getMessage()]);
        }
    }
    /**
     * 加载历史消息
     * @return \think\response\Json
     */
    public function loadHistory()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tdata_path'); // 关联的tdata标识
        $targetId = $this->request->post('target_id'); // 目标会话ID（群组/好友）
        $limit = $this->request->post('limit', 50); // 每页消息数，默认50
        $offset = $this->request->post('offset', 0); // 偏移量，用于分页
    
        // 参数验证
        if (empty($tdataId) || empty($targetId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path 或 target_id']);
        }
    
        try {
            // 获取账号的tdata路径和代理信息
            $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('tdata_path, proxyip')
                ->find();
    
            if (!$mtUser) {
                return json(['code' => 404, 'msg' => '未找到关联的账号信息']);
            }
    
            // 调用Python脚本获取历史消息
            $historyResult = $this->execPythonScript([
                'action' => 'get_history', // 对应Python脚本中的动作
                'tdata_path' => $mtUser['tdata_path'],
                'proxyip' => $mtUser['proxyip'],
                'target_id' => $targetId,
                'limit' => $limit,
                'offset' => $offset
            ]);
    
            if (!$historyResult['status']) {
                return json(['code' => 400, 'msg' => $historyResult['message']]);
            }
    
            // 整理消息数据（补充发送者信息）
            $messages = $historyResult['data']['messages'] ?? [];
            $formattedMessages = [];
    
            foreach ($messages as $msg) {
                // 区分发送者是否为当前账号（需提前获取当前账号user_id）
                $currentUserId = $this->getCurrentUserId($mtUser['tdata_path']); // 自定义方法获取当前账号ID
                $isOutgoing = $msg['sender_id'] == $currentUserId;
    
                // 格式化消息时间
                $msgTime = date('Y-m-d H:i:s', strtotime($msg['date']));
    
                $formattedMessages[] = [
                    'id' => $msg['id'], // 消息ID
                    'text' => $msg['text'] ?? '[无文本内容]', // 消息内容
                    'date' => $msgTime, // 发送时间
                    'sender_id' => $msg['sender_id'], // 发送者ID
                    'is_outgoing' => $isOutgoing, // 是否为当前账号发送
                    'media_type' => $msg['media_type'] ?? '', // 媒体类型（如image/voice）
                    'media_url' => $msg['media_url'] ?? '' // 媒体URL（如有）
                ];
            }
    
            return json([
                'code' => 200,
                'msg' => '加载成功',
                'data' => [
                    'messages' => $formattedMessages,
                    'has_more' => count($messages) >= $limit, // 是否还有更多消息
                    'total' => $historyResult['data']['total'] ?? count($formattedMessages) // 总消息数
                ]
            ]);
        } catch (Exception $e) {
            return json(['code' => 500, 'msg' => '加载历史消息失败：' . $e->getMessage()]);
        }
    }
    
    /**
     * 辅助方法：获取当前账号的user_id
     * @param string $tdataPath
     * @return int|string
     */
    private function getCurrentUserId($tdataPath)
    {
        $checkResult = $this->execPythonScript([
            'action' => 'check_tdata',
            'tdata_path' => $tdataPath
        ]);
        return $checkResult['data']['user_id'] ?? 0;
    }
    
    public function checkNewMessages()
    {
        // 获取请求参数
        $tdataId = $this->request->post('tdata_path');
        
        // 参数验证
        if (empty($tdataId)) {
            return json(['code' => 400, 'msg' => '缺少参数：tdata_path（账号标识）']);
        }
        
        try {
            // 1. 获取账号的基础信息（tdata路径、代理等）
            $mtUser = Db::name('mtuser')
                ->where('id', $tdataId)
                ->field('id, tdata_path, proxyip')
                ->find();
            
            if (!$mtUser) {
                return json(['code' => 404, 'msg' => '未找到对应的账号信息']);
            }
            
            // 2. 调用Python脚本获取全账号未读统计
            $result = $this->execPythonScript([
                'action' => 'count_total_unread',  // 对应Python脚本的动作标识
                'tdata_path' => $mtUser['tdata_path'],
                'proxyip' => $mtUser['proxyip']
            ]);
            
            // 3. 处理脚本返回结果
            if (!$result['status']) {
                // 脚本执行失败（如TDATA异常、网络问题）
                Log::warning("统计未读消息失败：{$result['message']}", [
                    'tdata_id' => $tdataId,
                    'tdata_path' => $mtUser['tdata_path']
                ]);
                return json([
                    'code' => 200,  // 非致命错误，返回0未读避免前端异常
                    'data' => ['unread' => 0]
                ]);
            }
            
            // 4. 格式化并返回结果
            return json([
                'code' => 200,
                'data' => [
                    'unread' => intval($result['data']['total_unread'] ?? 0),
                    'timestamp' => time()  // 便于前端判断统计时间
                ]
            ]);
            
        } catch (\Exception $e) {
            // 捕获异常并记录日志
            Log::error("checkNewMessages接口异常：{$e->getMessage()}", [
                'tdata_id' => $tdataId,
                'trace' => $e->getTraceAsString()
            ]);
            return json([
                'code' => 500,
                'msg' => '检查未读消息失败：' . $e->getMessage()
            ]);
        }
    }
    
    
    // 执行Python脚本
    private function execPythonScript($params)
    {
        $pythonScript = root_path() . 'python_scripts/telegram_manager.py';
        if (!file_exists($pythonScript)) {
            throw new \Exception("Python脚本不存在：{$pythonScript}");
        }
        
        $cmdParams = [
            '/www/server/pyporject_evn/versions/3.9.23/bin/python3',
            escapeshellarg($pythonScript),
            "--action=" . escapeshellarg($params['action']),
            "--api_id=" . escapeshellarg(config('telegram.api_id')),
            "--api_hash=" . escapeshellarg(config('telegram.api_hash'))
        ];

        
        foreach($params as $key => $value) {
            if($key != 'action') {
                if ($key=='proxyip') {
                    if(!empty($key)){
                        $parts = explode('##', $value);
                        if (count($parts) >= 3) {
                            list($ip_port, $username, $password) = $parts;
                            $proxy = "protocol://{$username}:{$password}@{$ip_port}";
                            $cmdParams[] = "--proxy " . escapeshellarg($proxy) . " ";
                        }
                    }
                }elseif($key=='tdata_path'){
                     $tdataPath=app()->getRootPath() .'public/'.$value;
                     $cmdParams[] = "--{$key}=" . escapeshellarg($tdataPath);
                }else{
                    $cmdParams[] = "--{$key}=" . escapeshellarg($value);
                    
                }
            }
        }
        
        $command = implode(' ', $cmdParams);
        Log::info("执行命令: {$command}");
        
        
        
        $process = popen($command, 'r');
        $output = stream_get_contents($process);
        $exitCode = pclose($process);
        $result = json_decode(trim($output), true);
        return $result;
        
        
        /*exec($command, $output, $returnVar);
        $jsonOutput = implode('', $output);
        $result = json_decode($jsonOutput, true);
        
        if(json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception("脚本执行结果解析失败: {$jsonOutput}");
            
        }
        
        return $result;*/
    }
    
	
	
}